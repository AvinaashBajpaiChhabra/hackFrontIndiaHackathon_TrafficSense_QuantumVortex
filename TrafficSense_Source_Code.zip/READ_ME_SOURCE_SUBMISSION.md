# TrafficSense source-code submission

This archive contains Python AI/backend source, the HTML/CSS/JavaScript dashboard, Arduino firmware, configuration examples, dependency specifications, tests, documentation, diagrams, and model preparation scripts.

To meet the 50 MB upload limit, pretrained model binaries, videos, virtual environments, databases, generated evidence, and runtime caches are excluded. The complete local project and these files remain in the original project folder. This source-only archive is not an offline ready-to-run bundle.

Setup (Python 3.11 recommended): run scripts/setup_environment.py from Code, then install requirements-vision.txt using the resulting environment's Python interpreter. Use scripts/download_models.py to obtain the vehicle/OCR models. Optional experimental emergency/head models use requirements-emergency.txt and scripts/prepare_models.py. These downloads need internet access.

Start from Code with python3 run.py --port 8773 --runtime runtime/user-session after setup. Open the dashboard and choose live mode, upload the selected videos, and configure calibration as described in docs/USER_DASHBOARD.md. Video-specific local calibration and the saved injected-ambulance demo configuration are not included. Real-world emergency and plate performance is not validated; injected demo events are explicitly labelled in code.

The source was packaged and archive integrity checked. A clean installation on a different computer has not been verified.
