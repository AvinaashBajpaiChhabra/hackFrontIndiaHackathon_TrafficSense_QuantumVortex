# Cleanup and recovery

Unused reference downloads, the original Word brief, superseded one-video scripts/screenshots and optional model-preparation caches were moved out of the active project.

Recovery archive:

`/Users/avinaashbajpaichhabra/.codex/visualizations/2026/10/25/01a17289-f569-7c11-9d88-645cf4c0a4e5/TrafficSense-archive-20261027-990d5fae`

The archive preserves relative paths. `MANIFEST.json` lists every moved item. Current uploads, evidence, event database, required inference/OCR models and the Python environment were retained. A small traffic image from the supplied reference ZIP is retained in `tests/fixtures/` solely for the optional software smoke check.
