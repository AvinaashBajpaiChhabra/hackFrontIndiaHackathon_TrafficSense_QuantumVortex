# Four-input architecture

```mermaid
flowchart LR
    A[Front video + calibration] --> T1[Front tracker]
    B[Right video + calibration] --> T2[Right tracker]
    C[Back video + calibration] --> T3[Back tracker]
    D[Left video + calibration] --> T4[Left tracker]
    T1 & T2 & T3 & T4 --> S[Common source-time scheduler]
    S --> O[Occupancy + observed lamp + pedestrian occupancy]
    S --> E[Emergency detection + temporal confirmation]
    O --> CTRL[Single controller]
    E --> Q[Priority queue]
    Q --> CTRL
    S --> I[Directed red crossing / stationary crossing obstruction / rider-head association]
    I --> W[Bounded evidence + OCR worker]
    W --> DB[SQLite review records + boxed full-frame JPEG]
    CTRL --> USB[USB bridge]
    USB --> UNO[Uno interlocks + watchdog]
    UNO --> LED[12 tabletop LEDs]
    CTRL & DB & S --> UI[Four-feed dashboard]
    UNO -->|Actual acknowledgement| UI
```

## Processing and clocks

One fair round-robin scheduler owns four independent YOLO/ByteTrack instances. Emergency/head models and the OCR reader are shared, without sharing tracking IDs. A file's processed frame time is its offset + common master time; decoding skips intermediate frames according to configured analysis FPS. Different input frame rates are supported. Successful road states publish together at the end of a processing cycle. Errors/EOF invalidate control immediately. Live cameras use approximate host-elapsed time, not camera hardware timestamps; mixed recorded/live sessions are rejected. CPU processing may lag wall time. The controller and Arduino clearance use real wall time; violation timing uses the source video clock.

The UI aliases Front/Right/Back/Left to internal North/East/South/West for compatibility with the existing four-slot serial pin map. These are configured approach identifiers, not claims about geographical compass orientation.

## Control

Only four fresh processing inputs enable normal control or hardware commands. Missing/stale/paused/EOF/error inputs force effective all-red and stop controller progress. A STOP command and board watchdog enforce hardware fallback independently. Last counts are labelled as retained measurements after EOF. The policy conservatively stops the junction when even one required input becomes unavailable.

One approach green at a time. Normal target is clamp(10 + 1.3 × occupancy, 10, 35) seconds. Waiting priority avoids repeatedly ignoring a quieter occupied approach; it is not an optimized network-flow model or strict wait bound. Emergency observations need three frames; one 20-second lease is active, other requests queue FIFO and expire after 60 wall seconds. Same-approach requests do not indefinitely renew a lease. Yellow and all-red remain 3s/2s.

A marked crossing containing an unambiguously non-rider person ends green through yellow and holds new green at all-red. A requested pedestrian phase starts a 10-second all-red walk period after clearance; actual occupancy may extend it. There is no dedicated pedestrian LED hardware. Only this conservative prototype phase plan is implemented, not a complete jurisdiction-specific traffic-rule engine.

## Incident rules

Red crossing requires a tracked bottom-center to cross the finite ordered stop line on observed red. Stale geometric tracks expire after 3 video seconds; duplicates are suppressed. HSV lamp estimation requires a tight crop, brightness/saturation/color thresholds and three identical observations. A source-time CSV can replace the crop. Unknown/yellow/green do not create red violations. Sub-frame color changes and tracker ID switches remain limitations.

Crossing obstruction uses a calibrated polygon and near-stationary bottom-center occupancy for a configurable period (default 3s). Moving through the crossing does not trigger automatically. This is a review rule, not proof of an offence under every local law.

Helmet checks use explicit helmet/bare-head detections. A head must lie in a person's upper region, with a unique spatial association to one motorcycle. Tiny, missing, low-score, ambiguous and conflicting evidence is uncertain. Three repeated positive bare-head associations are required. The current prompt-based model is experimental; a trained head/helmet detector is preferable for evaluation. It cannot infer whether an emergency is officially on duty.

## Evidence and persistence

A bounded 16-job queue decouples frame capture from plate OCR. Full-frame evidence is annotated with vehicle box, calibration boundary, place, road, type and video time. A vehicle crop and successful plate crop are stored separately. Unread plates are retained. On stop, pending work skips OCR but preserves evidence; queue saturation still records a clearly marked evidence-unavailable incident. Disk/database failures surface as errors.

SQLite migrations add incident type, place, source/capture times, crop URLs, detector confidence, review status, details and session ID without deleting prior records. Manual review changes status/plate text only. Confidence values are raw model scores. Current manual edits have no audit trail; adding one is future work.

## API

- `GET /api/state`: four camera states, controller/effective signals, queue, pedestrian state, capabilities, events and real board status.
- `GET /api/setup`: checkpoint names, dependency availability, USB ports, previews and saved calibration.
- `POST /api/upload?approach=...`: bounded raw video upload and first frame.
- `POST /api/preview`: take a frame at a recorded-video time; updates preview token.
- `POST /api/camera`: preview an explicitly selected local USB camera index.
- `POST /api/start`: require four unique calibrated source tokens; start session.
- `POST /api/stop`, `/api/action/pause`, `/api/action/cancel-priority`, `/api/action/pedestrian`: lifecycle/phase controls.
- `POST /api/priority`: labelled operator priority request.
- `GET /api/events` and `/api/events.csv`: type/approach filters; up to 200 JSON rows / 10,000 CSV rows.
- `POST /api/events/review`: correct plate text and mark needs-review/confirmed/dismissed.
- `GET /api/frame.jpg?approach=...`, `/api/preview.jpg?approach=...`, `/evidence/<name>.jpg`: local media.
- `POST /api/hardware/connect` and `/disconnect`: explicit USB bridge.

The server binds only to 127.0.0.1, rejects browser cross-origin mutations, generates opaque upload names, validates normalized geometry and escapes formula prefixes in CSV. No public hosting/authentication/automated fines are implemented.

References: [Ultralytics tracking](https://docs.ultralytics.com/modes/track/), [YOLO-World](https://docs.ultralytics.com/models/yolo-world/), [EasyOCR](https://www.jaided.ai/easyocr/documentation/), [Uno pinout](https://content.arduino.cc/assets/Pinout-UNOrev3_latest.pdf).
