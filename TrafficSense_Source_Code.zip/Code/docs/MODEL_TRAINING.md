# AI model development

The working pipeline uses local YOLO11 vehicle/person detection, independent ByteTrack contexts for four cameras, optional emergency/head detectors, calibrated geometry and EasyOCR. Emergency and helmet prompt checkpoints are experimental; no custom trained accuracy is claimed.

## Fine-tune on labelled footage

Use reviewed images exported in YOLO detection format. Keep whole recordings/capture sessions in one split: adjacent frames from the same video must not appear in training and validation/test. Include ordinary vehicles, occlusion, day/night conditions and reviewed negative images. Never label an obscured head as a bare head.

Layout under `runtime/datasets/emergency` (similarly helmet or plate):

```
images/train/   labels/train/
images/val/     labels/val/
images/test/    labels/test/
```

Each image has a corresponding `.txt` annotation with rows `class_id center_x center_y width height`, normalized to 0–1. Empty annotation files explicitly mark reviewed negatives. All classes must have examples in each split. Class IDs, in order:

- emergency: `ambulance`, `police car`, `fire truck`, `car`, `truck`, `bus`, `motorcycle`
- helmet: `motorcycle helmet`, `bare human head` (box the helmet/head, not the whole rider)
- plate: `license plate`

Validate without loading ML dependencies:

```sh
.venv/bin/python scripts/train_detector.py --task emergency --dataset runtime/datasets/emergency --check-only
```

Train from the installed local pretrained checkpoint and evaluate the best checkpoint on held-out test images:

```sh
.venv/bin/python scripts/train_detector.py --task emergency --dataset runtime/datasets/emergency --epochs 50 --device cpu
```

Use `--device mps` on a compatible Apple GPU or `--device 0` on CUDA. These are selectable execution targets, not tested performance claims. Runs, dataset configuration and `evaluation.json` are written under `runtime/training/`. The test split is not used to select training checkpoints. Do not repeatedly tune against the test set. The validator checks annotation ranges, class coverage and exact duplicate leakage; it does not check image readability, annotation correctness or near-duplicate/video leakage. Review these separately.

After evaluation, select the resulting absolute `weights/best.pt` path as `emergency_model`, `helmet_model` or `plate_model` in session configuration. No automatic replacement occurs. Keep the base vehicle model for people/motorcycle tracking. Confidence scores are not accuracy percentages. Evaluate temporal incident precision/recall, OCR exact match/unread rate and emergency false requests on separate intersection recordings before claiming operational performance.

The OCR path joins recognized fragments left-to-right and top-to-bottom for single/two-line plates. It still depends on a suitable plate crop and may fail on blur, glare or tiny text.

No labelled training dataset is bundled. The traffic-photo fixture is a plumbing test, not training or evaluation data.

API references: [Ultralytics training](https://docs.ultralytics.com/modes/train/), [detection dataset format](https://docs.ultralytics.com/datasets/detect/).
