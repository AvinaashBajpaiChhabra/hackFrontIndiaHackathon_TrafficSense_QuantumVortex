# Backend for the supplied TrafficSense.html

The dashboard keeps the supplied design, layout, road controls and demo behavior. With user approval, its upload JavaScript now releases file-input focus, refreshes immediately after uploads, prevents refresh during an active upload, and clears a superseded local demo preview. Source: `TrafficSense_Final/TrafficSense.html`. Served copy: `trafficsense/static/TrafficSense.html`.

## Run locally

From the TrafficSense project folder:

```sh
python3 run.py --port 8773 --runtime runtime/user-session
```

Open http://127.0.0.1:8773/ and choose **Use live**. The unchanged HTML starts in demo mode. Upload after choosing Use live: demo uploads remain only in the browser and are not sent to Python. If you already uploaded in demo mode, reload, choose Use live and upload again. Double-clicking the HTML file supports its standalone demo, but cannot connect its relative `/api` URL to Python; serve it through this command.

The dedicated runtime keeps this session separate from older uploads and test records. No camera or Arduino is opened automatically. User uploads, calibration and evidence remain local. Stop the local server with Ctrl+C.

## Implemented contract

| Route | Purpose |
|---|---|
| GET `/api/snapshot` | UI-shaped camera array, recommendations, incidents, emergency requests and actual Arduino acknowledgements |
| GET `/api/calibration/geometry` | The supplied three marking types, normalized coordinates |
| POST `/api/cameras/front/video` | Single FormData part named `video`; also `right` |
| PUT `/api/cameras/front/calibration` | `{ "markings": { "stop": [{"x":...,"y":...},...], "traffic": [...], "pedestrian": [...] } }` |
| POST `/api/cameras/front/connect` | `{ "url": "usb:0" }`; local USB index only, no network/RTSP implementation claimed |
| POST `/api/control` | `{ "action": "start" }`, `pause`, `stop`, `emergency-stop` |
| POST `/api/priority` | `{ "road": "Right", "source": "manual" }`; server labels it operator-issued |
| PATCH `/api/incidents/123` | `{ "status": "Confirmed", "plate": "..." }`; also Needs review / Dismissed |
| POST `/api/hardware/connect` | `{ "port": "an enumerated USB port" }` |

The UI shows Front and Right in Overview. A single uploaded video can run vehicle counting without calibration. With incomplete calibration, counting uses the full frame and signal recommendations, priority, violations and Arduino control remain disabled. Both inputs must be calibrated and fresh to enable intersection control. The shared controller schedules only those roads. The fourth serial slot remains red; it cannot steal a green phase. Pause, Stop, missing/stale input, errors and EOF request all-red. Recommendations are omitted during yellow/all-red clearance so the UI does not falsely show a new green during transition. Actual hardware state remains Unknown until a valid physical acknowledgement arrives.

## Calibration meaning

- **Stop line:** two ordered endpoints across the selected approach.
- **Traffic line:** two endpoints across the same approach upstream of the stop line. The bounding rectangle of these four endpoints defines the counting region. Crossing direction is derived from which side is upstream. Keep the region within the approach, excluding parked/opposing traffic; this rectangle is an approximation for diagonal roads.
- **Pedestrian crossing:** four ordered boundary corners of the visible crossing.

Red-light evidence additionally needs the actual governing lamp state. The supplied UI has no lamp-crop control. The calibration API therefore accepts an optional `signal_roi: [x1,y1,x2,y2]` field alongside `markings`. Coordinates are normalized. Without it, observed light is Unknown and no red-light event is invented from recommendations or Arduino LEDs. Configure a lamp only if it governs that movement; a visible unrelated lamp is insufficient. Saving again through the supplied UI clears a separately provided lamp crop, so set that API field after the UI calibration.

## Unchanged UI limitations

These restrictions are present in the supplied HTML, and were not silently rewritten:

1. Global **Calibrate** always opens Front. Right calibration needs PUT requests through the API; there are no per-road calibration buttons in this file.
2. **Connect Live Feeds** is hard-coded unavailable and shows “No arduino linked”. This button cannot become a functioning camera control from a backend response alone. Video upload and the API's USB endpoint do not require an Arduino.
3. The browser retains a saved calibration frame in memory. Reload after replacing a previously calibrated input, choose Use live, then recalibrate. The server invalidates saved calibration and clears stale counts/annotated frames when a source changes.
4. Live-mode calibration should use the backend preview. A manually substituted reference-image file is not transmitted with the markings; the backend cannot verify that it belongs to the video.
5. **Clear all** clears the browser list only. It does not delete persistent incident records; polling returns them. CSV export works on the displayed records. No destructive database-delete endpoint was added.
6. Location labels are hard-coded to Pitampura Intersection, so this adapter uses that name. This is a demonstration label, not verified camera location.
7. Front/Right Start buttons all control the shared session, as specified by their existing HTML event handler. They do not start independent controllers.

These prevent a completely UI-only setup of both cameras with this exact file. They require API actions unless the user later authorizes frontend changes.

## Arduino

Use `arduino/TrafficSenseController/TrafficSenseController.ino`. The serial protocol stays Front/Right/Back/Left. For a two-group LED model, wire Front D2/D3/D4, Right D5/D6/D7 for red/yellow/green, each LED through its own 1kΩ resistor to common GND. Unused Back and Left groups remain red. USB runs at 115200 baud. Firmware retains clearance, conflict rejection, STOP and the three-second watchdog. Do not infer physical light state from a recommendation.

## Validation

Unit/controlled integration checks cover multipart uploads, marking validation, persistence, input replacement, two-road scheduling, stale all-red fallback, evidence/review shape and PATCH/origin handling. `scripts/verify_user_dashboard.py --port 8773` performs two real-model uploads and API tests using repeated-photo fixtures against an isolated test runtime. It checks pause/resume, manual priority and EOF all-red; it is not a detection-accuracy benchmark. Do not run that script against your submission session: use a separate `--runtime runtime/final-ui-check` server.

Emergency and helmet checkpoints remain experimental. Full plate OCR is not validated on real junction recordings. The Arduino firmware was tested with native I/O stubs; board-specific upload and physical LEDs still need a connected board.

## Cumulative passage count

In live mode, Vehicles passed is the session total of unique tracker IDs crossing the counting segment. Calibrated inputs use the directed stop line; uncalibrated inputs use the visible horizontal mid-frame line in either direction. A stationary vehicle does not increase the total. Each track counts at most once per run; pause preserves totals, while a new run or replacement restarts them. Backend `count` remains current ROI occupancy for signal timing; `total_passed` supplies the dashboard total. The total is an estimate: missed detections, occlusion and tracker ID changes can cause errors.

## Carriageway-only counting calibration

The calibration API also accepts `{"counting":{"region":[[x,y],...],"line":[[x,y],[x,y]],"direction":1}}`. The polygon excludes the opposite carriageway from passage counts, occupancy and displayed boxes; the segment counts only the selected direction. This is counting geometry, not a verified stop line or pedestrian crossing, and does not enable signal control or violations. Calibration is persisted for that upload and invalidated when its video is replaced. The Right-road busy-road demonstration has been configured this way.

## Injected ambulance presentation demo

`runtime/user-session/demo-scenario.json` explicitly enables a simulated ambulance for the current Right upload ID. Each new run picks a random trigger between 3–7 video seconds and one tracked vehicle within the selected region. The frame and dashboard label it SIMULATED; it is never reported as an AI detection. A 15-second Right Green advisory overrides density-based demo recommendations, then expires. Other road recommendations show Red. Pause/stop/stale inputs suppress recommendations. This demo never issues Arduino priority or bypasses clearance and does not enable the uncalibrated physical controller. Replacing the Right input disables the scenario until explicitly re-enabled for that upload.
