# File guide

## Current project

- `../run.py`: starts the local dashboard/backend.
- `../trafficsense/`: implementation, tracking, counting, calibration, signal logic, and APIs.
- `../trafficsense/static/TrafficSense.html`: the dashboard served by Python.
- `../arduino/TrafficSenseController/TrafficSenseController.ino`: LED controller firmware.
- `USER_DASHBOARD.md`: current two-input dashboard guide.
- `ARDUINO_HARDWARE.md`: hardware setup reference.
- `MODEL_TRAINING.md`: optional model training reference.
- `assets/`: original transparent PNG diagrams.
- `../Submission/`: grouped presentation, report, and diagram copies.

## Supporting material

`ARCHITECTURE.md`, `IMPLEMENTATION_PLAN.md`, `UI_BACKEND_HANDOFF.md`, `FOUR_SOURCE_REFERENCE.md`, and the four-road screenshots/results preserve earlier design and test history. Some describe previous versions; use USER_DASHBOARD.md for current behavior.

`../runtime/qa/` groups loose development artifacts into `screenshots/`, `reports/`, `backups/`, and `extracted-js/`. Other QA runtime directories stay in place because their saved configurations can reference local video paths.

The active `../runtime/user-session/`, model caches, databases, source videos, virtual environment, and dependency files were preserved at their existing paths. Nothing was deleted. `FILE_ORGANIZATION.json` records moved files for reference or reversal.

The separate sibling `TrafficSense_Final/TrafficSense.html` remains at its original location; this organization applies to the TrafficSense project folder.
