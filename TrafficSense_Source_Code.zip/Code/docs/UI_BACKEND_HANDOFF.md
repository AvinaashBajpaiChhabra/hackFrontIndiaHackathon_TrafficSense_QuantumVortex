# UI → Python backend handoff

Keep AI processing in Python and hardware actuation in the Arduino sketch. The current API is served on the same origin as the dashboard. A separate React dev server should proxy `/api` and `/evidence` to the Python server; cross-origin mutations are rejected. Do not invent WebSocket, RTSP or authentication support: the current inputs are uploaded recordings or local USB camera indices.

| Method/path | Purpose |
|---|---|
| GET `/api/setup` | Models, dependency checks, USB ports, saved config and preview tokens |
| GET `/api/state` | Poll current road analysis, recommendations, pipeline and hardware state |
| POST `/api/upload?approach=Front` | Raw video bytes, `X-File-Extension: .mp4`, optional URL-encoded `X-Source-Name`; max 500 MB |
| POST `/api/camera` | JSON `{ "approach": "Front", "index": 0 }` |
| POST `/api/preview` | JSON `{ "approach": "Front", "seconds": 4 }`; returns a fresh preview token |
| GET `/api/preview.jpg?approach=Front` | Calibration image |
| POST `/api/start` | JSON `{ "config": ... }`; each source needs its current `preview_id` |
| GET `/api/frame.jpg?approach=Front` | Latest annotated JPEG; use a cache-busting query while polling |
| POST `/api/stop` | Stop processing; hardware all-red requested |
| POST `/api/priority` | JSON `{ "approach": "Front", "vehicle": "Ambulance" }`; labels request as operator-originated |
| GET `/api/events` | Incident records; optional `kind` and `approach` filters |
| POST `/api/events/review` | JSON `{ "id": 1, "status": "confirmed", "plate": "DL01AB1234" }` |
| GET `/api/events.csv` | Download filtered records |
| POST `/api/hardware/connect` | JSON `{ "port": "an enumerated USB port" }` |
| POST `/api/hardware/disconnect` | Disconnect board |

Read `config/session.example.json` for configuration structure. Road aliases map Front/Right/Back/Left to North/East/South/West. All drawing coordinates are normalized 0–1. `roi` is the vehicle-counting rectangle, `stop_line` has two ordered endpoints, `direction` selects its crossing direction, `signal_roi` is the observed lamp crop and `crosswalk` is a four-corner polygon. The phrase “traffic line” must be represented by an explicit geometry/meaning in the UI, rather than silently conflated with the lamp or vehicle region. Red-light detection needs an observed lamp or synchronized signal timeline.

Refresh a preview token after seeking/changing input and recalibrate it; stale tokens are rejected. All four recorded videos or four distinct USB cameras are required. Do not treat unknown counts as zero or an unread plate as a successful recognition. A UI recommendation is distinct from camera-observed signal state and Arduino acknowledgement. Model/image endpoints may fail while loading; show error/unknown state rather than fabricated data.

## Default pretrained profile

`GET /api/models` returns the default profile and offline weight-file availability for the UI setup screen. `files_ready` checks nonempty files only. It does not claim successful model loading or accuracy. After analysis starts, use `/api/state` → `capabilities` for loaded model availability. Omitted model selections now use YOLO11 vehicles, experimental emergency/head checkpoints and EasyOCR; an explicit `null` disables an optional model. Dedicated plate detection is optional; the installed baseline uses contour localization and OCR.
