# TrafficSense — four videos, one Arduino junction

A local four-road prototype with **Front, Right, Back and Left** inputs. Each video has its own calibration and YOLO/ByteTrack context. One central controller recommends signal timing, queues emergency priority and controls a tabletop Arduino LED junction.

## Start

From this folder:

```sh
python3 run.py
```

Open **http://127.0.0.1:8765**. If an old server is already running, stop it with Ctrl+C and restart to load this version. For a different port: `python3 run.py --port 8767`. The launcher uses the installed project Python 3.11 environment; no shell activation is needed. The workspace name contains colons, so use the supplied environment helper when reinstalling.

## Upload → mark a frame → analyse

1. Upload one video for each road. USB camera indices are supported too; use either four recorded inputs or four distinct live cameras, not a mixture.
2. Select **Mark frame** for that road. Choose a frame time and press **Take frame** if the first frame is unsuitable. The camera must remain fixed.
3. Mark the upstream **vehicle region** with two corners.
4. Mark the **stop line** with ordered endpoints A/B. The arrow shows the checked direction; reverse it if needed.
5. Mark a tight crop around the **actual traffic lamp**. Unknown/ambiguous/missing light states never generate red-light events.
6. Mark the **pedestrian crossing** with four boundary corners if obstruction monitoring is needed. A moving vehicle passing legally over it is not automatically an incident.
7. Set the road's **video offset** to align the recordings. Calibration-frame time does not change playback offset. If capture start is known, enter it; otherwise event time remains video-relative.
8. Save that road's calibration. Repeat for all four. Enter the junction/place name and **Analyse all four videos**.

Saved input/calibration configuration is restored without automatically starting video/camera access. Browser-local unsaved drawings stay tied to their preview token. Model choices and analysis frame rate are under **Models, processing & calibration status**.

## Signals, emergency and pedestrians

Normal green is bounded to 10–35 seconds, based on approach occupancy and waiting priority. A quieter waiting approach is eventually served; the 90-second priority threshold is not a guaranteed maximum wait. One approach is served at a time. This is a prototype heuristic, not a traffic-engineered optimization result.

Confirmed emergency-model observations request priority. First active priority wins; other approaches queue. Switching retains **3s yellow + 2s all-red**. Priority leases are bounded to 20 seconds, including clearance, rather than being renewed indefinitely for a parked vehicle. The operator button is separately labelled.

Tracked pedestrians inside a marked crossing prevent the next green until clear; clearly associated motorcycle riders are excluded from pedestrian occupancy. A requested pedestrian phase holds all vehicle lights red for 10 seconds after normal clearance. No physical pedestrian lamp is implemented.

All **four** inputs must be processing and fresh for control to progress. Pause, loading, EOF, stale data (>5 seconds by default), missing inputs and errors request Arduino all-red. Last measured counts/images remain visible after EOF. Recorded videos share a source-time schedule and can be processed slower than real time on CPU. Dashboard FPS is actual analysed throughput per feed, not model-only speed.

## Separate violation review table

- **Red-light crossing:** a tracked vehicle crosses the finite stop line in the configured direction during observed red.
- **Pedestrian-crossing obstruction:** the vehicle's ground-contact point remains inside the marked crossing with limited motion for the configurable duration (default 3 source-video seconds).
- **Rider without helmet:** an explicit uncovered-head detection must associate uniquely with a tracked rider and motorcycle and repeat across three frames. No helmet detection alone, an obscured/tiny head, ambiguity or conflicting helmet evidence is **uncertain**, not a violation.

Each record stores junction/place, approach, video time, optional capture datetime, processing UTC, incident type, session-qualified track ID, model confidence, optional plate/OCR score, boxed full-frame evidence, vehicle crop, optional plate crop and review status. OCR failure remains **Unread**. Filter by road/type, correct plate text, confirm/dismiss candidates and export CSV. Existing event databases are migrated without deleting old rows. The table shows the latest 200 events; filtered CSV exports up to 10,000.

Only the **observed light in the input video** establishes a recorded red-light event. The recommended light and Arduino acknowledgement are different signals. Changing LEDs cannot change prerecorded traffic lights.

## Models and validation limits

Installed local runtime models:

- `yolo11n.pt`: general vehicle/person tracking.
- `emergency-world.pt`: **experimental zero-shot** ambulance, police-car and fire-truck prompts, with ordinary-vehicle distractors.
- `helmet-world.pt`: **experimental zero-shot** motorcycle-helmet and bare-head prompts. Association/temporal checks reduce ambiguity, but do not establish real-world accuracy.
- English EasyOCR weights. Plate localization can use a dedicated trained plate detector; otherwise a basic contour/aspect-ratio fallback is used.

A validated custom emergency/head detector can replace the experimental checkpoints. Imported checkpoints must be trusted files. There is no registration-database lookup, automatic fine or claim that every traffic regulation is enforced. Detection/OCR scores are not calibrated accuracy estimates. Real helmet accuracy needs labelled, readable footage. Dark, distant, crowded and occluded scenes need further evaluation.

## Arduino

See **docs/ARDUINO_HARDWARE.md**. Reference circuit: Uno R3, 12 LEDs, 12 × 1kΩ resistors, breadboard, jumpers and USB data cable. Laptop runs AI; firmware operates the lights, rejects conflicts, enforces clearance and has a communication watchdog. Connect explicitly from the dashboard. Acknowledgement order is **Front / Right / Back / Left** (internally N/E/S/W). No board is simulated. Physical board/camera tests remain pending.

## Reinstall

Use Python 3.11:

```sh
python3.11 scripts/setup_environment.py
.venv/bin/python -m pip install -r requirements-vision.txt
.venv/bin/python scripts/download_models.py
# Optional: rebuild experimental prompt checkpoints
.venv/bin/python -m pip install -r requirements-emergency.txt
.venv/bin/python scripts/prepare_models.py
.venv/bin/python scripts/prepare_models.py --helmet
```

Model preparation requires internet if weights are absent; inference uses local weights. Dependencies from the tested environment are recorded in `requirements-vision.lock.txt`. `config/session.example.json` documents the four-source schema; its example coordinates must be calibrated to your footage. CLI replay: `python3 run.py --config runtime/last-session.json`.

## Verification

```sh
.venv/bin/python -m unittest discover -s tests -v
node --check trafficsense/static/app.js
# Optional real-model/API smoke check against an isolated server:
python3 run.py --port 8767 --runtime runtime/qa-four-inputs
# In another terminal:
.venv/bin/python scripts/verify_four_inputs.py --port 8767
```

The controlled integration test uses mocked detections and real OpenCV video/evidence IO to check three incident types, tracker isolation and uncertain-case exclusion. The optional real-model check uses four copies of a repeated traffic photo, explicitly labelled as a test, not real four-road footage. Results are in `docs/four-input-smoke-results.json`. These checks verify software plumbing; they do not benchmark real emergency/helmet/plate accuracy or physical Arduino operation.

## Essential layout

`trafficsense/` contains controller, incidents, storage, video helpers, scheduler, server, serial bridge and static dashboard. `arduino/` contains the sketch. `config/`, `tests/`, `scripts/` and `docs/` hold configuration, verification, setup and operating instructions. `runtime/` holds local models, uploads, saved calibration, evidence and SQLite data; it is excluded from version control.

Unused original references and superseded generated files are recoverable from the archive listed in `docs/CLEANUP.md`.

## Backend development handoff

See [UI API integration](docs/UI_BACKEND_HANDOFF.md) for the new dashboard, and [custom model training](docs/MODEL_TRAINING.md) for dataset checks, fine-tuning and held-out evaluation. The training command needs labelled data; existing prompt models remain experimental.

The backend defaults to the installed pretrained vehicle, emergency and helmet model set when a model field is omitted; explicit `null` disables an optional detector. `GET /api/models` exposes offline weight-file availability. The UI should retain the experimental labels for emergency/head recognition.
