# Arduino tabletop junction

Use a laptop for video, YOLO tracking, OCR, emergency recognition and dashboard. An Arduino Uno R3 receives the resulting four signal aspects over USB and drives low-current indicator LEDs. The board does not run YOLO or receive the video stream.

## Parts

- Arduino Uno R3 (reference board) + data-capable USB A/B cable, or appropriate adapter for your laptop.
- Four red, four yellow and four green LEDs.
- Twelve **1 kΩ** resistors, one per LED.
- Breadboard and jumper wires.
- Laptop camera / USB webcam for a live demonstration; uploaded video needs no camera hardware.
- Optional cardboard junction and toy vehicles for presentation.

No shopping order was placed. The Uno R3 is the reference pinout; other boards need their own pin/current checks. The code also uses pins available on a classic Nano, but that board has not been tested.

## Wiring

| Approach | Red anode via 1kΩ | Yellow anode via 1kΩ | Green anode via 1kΩ |
|---|---:|---:|---:|
| Front (N) | D2 | D3 | D4 |
| Right (E) | D5 | D6 | D7 |
| Back (S) | D8 | D9 | D10 |
| Left (W) | D11 | D12 | D13 |

Each GPIO goes through its own resistor to the LED anode (long leg). Every LED cathode goes to the breadboard common GND rail; connect that rail to Arduino GND. Keep D0/D1 free for USB serial. Power the board from USB. These resistor values keep individual indicator currents low; this circuit is for breadboard LEDs, not high-current lamps.

```mermaid
flowchart LR
    V[Video / USB camera] --> P[Laptop: detection + OCR + priority]
    P --> D[Dashboard]
    P --> S[USB serial bridge]
    S --> A[Uno R3 firmware]
    A --> R[4 red LEDs]
    A --> Y[4 yellow LEDs]
    A --> G[4 green LEDs]
```

## Firmware and connection

1. Install the official Arduino IDE and select **Arduino Uno** and the attached USB port.
2. Open `arduino/TrafficSenseController/TrafficSenseController.ino`, verify and upload it.
3. Close Serial Monitor so the Python bridge can open the port.
4. Start TrafficSense, refresh USB ports and explicitly select **Connect**. Only USB-style serial ports are offered.
5. The dashboard shows the board's acknowledged aspects in **Front/Right/Back/Left (N/E/S/W)** order. `GRRR` means North green; `RRRR` means all-red. A dashboard recommendation alone is not proof of a board acknowledgement.
6. Disconnect from the dashboard before uploading new firmware.

## Protocol

115200 baud, 8N1, newline-terminated ASCII:

- Host: `SET 42 GRRR` → board: `ACK 42 GRRR`.
- Conflicting/invalid or premature command: `NACK 42 <current>`.
- Host: `STOP 43` immediately requests all-red and acknowledges the actual all-red state.
- Same-aspect commands are heartbeats and do not restart clearance timing.

The firmware accepts at most one non-red approach. Normal switching requires green → yellow for at least 3 seconds → all-red for at least 2 seconds → new green. On boot it starts all-red. Missing valid commands for 3 seconds forces all-red. STOP and the watchdog can force all-red immediately. Input overflow is rejected. The bridge repeats commands and reports acknowledgements; the firmware may lag a recommendation while enforcing its own clearance interval.

For video, any required stale input (>5 seconds by default), pause, loading, end-of-file and errors request all-red. This freshness limit may need adjustment after profiling slow OCR/hardware. In synthetic demo mode, the LEDs follow the clearly marked simulation if you explicitly connect them.

## Priority demo

A confirmed emergency-model observation (three consecutive detections in a calibrated approach) requests a bounded 20-second priority lease. An operator can also request a clearly labelled test override. Priority ends competing green at the next control tick, then preserves clearance. It is not simultaneous conflicting green and is not literal zero-second switching. Do not present a prompt-based model as a validated emergency classifier.

## Verification status

The sketch's transition rules, conflict rejection, early-green rejection, STOP and watchdog passed a native C++ test with mocked Arduino I/O. An Uno-specific compile/upload and actual LED/USB test are still required because no board is connected. This is an educational tabletop circuit, not a roadway controller.

References: [official Uno R3 pinout](https://content.arduino.cc/assets/Pinout-UNOrev3_latest.pdf), [Uno R3 hardware documentation](https://docs.arduino.cc/hardware/uno-rev3/), [pySerial port enumeration](https://pyserial.readthedocs.io/en/latest/tools.html).

All four required inputs must remain fresh. One input ending or failing holds all-red even while other videos continue analysis. A requested pedestrian phase and observed pedestrian occupancy can hold all-red before any new green.

Read-only diagnostics: `STATUS 44` returns `STATE 44 <current>` without changing lights or refreshing the command watchdog. Diagnostics cannot keep a green signal alive after the control connection stops sending valid commands.
