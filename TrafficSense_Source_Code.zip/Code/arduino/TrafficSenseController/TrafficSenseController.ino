/* TrafficSense tabletop LED junction. UNO R3 / classic Nano.
   N R/Y/G: 2/3/4, E: 5/6/7, S: 8/9/10, W: 11/12/13.
   One 1k resistor per LED; cathodes to common GND. USB serial 115200.
   Protocol: SET <sequence> <NESW codes>\n -> ACK <sequence> <actual codes>\n
   Codes R/Y/G. One non-red maximum. Firmware independently enforces clearance.
   Educational LEDs only; do not connect to road signals or mains.
*/
const byte pins[4][3]={{2,3,4},{5,6,7},{8,9,10},{11,12,13}};
char current[5]="RRRR";
char buffer[48];
byte used=0;
bool overflowed=false;
unsigned long changedAt=0,lastValid=0;
const unsigned long yellowMs=3000,allRedMs=2000,watchdogMs=3000;

void apply(const char *next){
  // Turn every green/yellow off before enabling any new aspect.
  for(byte i=0;i<4;i++){digitalWrite(pins[i][1],LOW);digitalWrite(pins[i][2],LOW);}
  for(byte i=0;i<4;i++){
    digitalWrite(pins[i][0],next[i]=='R'?HIGH:LOW);
    if(next[i]=='Y')digitalWrite(pins[i][1],HIGH);
    if(next[i]=='G')digitalWrite(pins[i][2],HIGH);
  }
  if(strcmp(current,next)!=0){strcpy(current,next);changedAt=millis();}
}

bool allowed(const char *next){
  if(strlen(next)!=4)return false;
  int oldLane=-1,newLane=-1;
  for(byte i=0;i<4;i++){
    if(next[i]!='R'&&next[i]!='Y'&&next[i]!='G')return false;
    if(current[i]!='R')oldLane=i;
    if(next[i]!='R'){if(newLane!=-1)return false;newLane=i;}
  }
  if(strcmp(next,current)==0)return true;
  if(newLane==-1){
    // Fail-safe red is always permitted, but cannot immediately go green again.
    return oldLane==-1 || (current[oldLane]=='Y' && millis()-changedAt>=yellowMs);
  }
  unsigned long elapsed=millis()-changedAt;
  if(oldLane==-1)return next[newLane]=='G'&&elapsed>=allRedMs;
  if(newLane!=oldLane)return false;
  return current[oldLane]=='G'&&next[newLane]=='Y';
}

void command(){
  unsigned long seq;char requested[8],extra;
  // Read-only diagnostics must not keep an abandoned green alive.
  if(sscanf(buffer,"STATUS %lu %c",&seq,&extra)==1){Serial.print("STATE ");Serial.print(seq);Serial.print(' ');Serial.println(current);return;}
  if(sscanf(buffer,"STOP %lu %c",&seq,&extra)==1){apply("RRRR");lastValid=millis();Serial.print("ACK ");Serial.print(seq);Serial.println(" RRRR");return;}
  if(sscanf(buffer,"SET %lu %7s %c",&seq,requested,&extra)!=2)return;
  bool valid=allowed(requested);
  // Yellow must run fully for normal clearance. STOP/watchdog can fail safe early.
  if(valid){apply(requested);lastValid=millis();}
  Serial.print(valid?"ACK ":"NACK ");Serial.print(seq);Serial.print(' ');Serial.println(current);
}

void setup(){
  for(byte i=0;i<4;i++)for(byte j=0;j<3;j++)pinMode(pins[i][j],OUTPUT);
  apply("RRRR");changedAt=millis();lastValid=millis();Serial.begin(115200);
}
void loop(){
  while(Serial.available()){
    char c=Serial.read();
    if(c=='\n'){
      if(!overflowed){buffer[used]='\0';command();}
      used=0;overflowed=false;
    }else if(c!='\r'){
      if(used<sizeof(buffer)-1)buffer[used++]=c;else overflowed=true;
    }
  }
  if(millis()-lastValid>watchdogMs)apply("RRRR");
}
