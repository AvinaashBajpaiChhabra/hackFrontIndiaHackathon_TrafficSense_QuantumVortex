# TrafficSense

Two-road traffic video analysis with vehicle tracking, cumulative passage counts, a dashboard, and an Arduino LED signal prototype.

## Run the dashboard

```sh
python3 run.py --port 8773 --runtime runtime/user-session
```

Open http://127.0.0.1:8773/ and choose **Use live**. Front and Right are the two video inputs. Live mode shows annotated backend frames. The configured Right-road region follows the approaching carriageway left of the divider.

The current presentation demo includes an explicitly simulated ambulance event in the second video and advisory signal phases. This is separate from validated emergency recognition and physical Arduino control.

## Find your files

| Folder | Contents |
|---|---|
| [Submission](Submission/README.md) | Presentation, report, and transparent diagrams |
| `trafficsense/` | Python AI/backend code and dashboard in `static/TrafficSense.html` |
| `arduino/TrafficSenseController/` | Arduino firmware |
| `demo_videos/normal_speed/` | Video inputs and source notes; includes a separately named timelapse reference |
| `config/` | Example session and signal configurations |
| [docs](docs/FILE_GUIDE.md) | Technical documentation and file guide |
| `scripts/` | Model preparation, training, and verification utilities |
| `tests/` | Automated checks |
| `runtime/user-session/` | Active uploads, calibration, evidence, database, and server log |
| `runtime/models/`, `runtime/easyocr/` | Downloaded model files |
| `runtime/qa/` | Organized screenshots, reports, HTML backups, and extracted test scripts |

Dependency files and `run.py` stay at the root so existing commands keep working. The virtual environment and other runtime directories are retained. No files were deleted.

See [USER_DASHBOARD.md](docs/USER_DASHBOARD.md) for calibration/API details and current limitations. Historical four-road architecture references are retained for context.
