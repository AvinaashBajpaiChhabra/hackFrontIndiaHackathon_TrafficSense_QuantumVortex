"""Shared video/model helpers for the four-input scheduler."""
import csv
import json
import math
import os
import re
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
MODELS=ROOT/'runtime/models'
os.environ.setdefault('YOLO_CONFIG_DIR',str(ROOT/'runtime/ultralytics'))
os.environ.setdefault('MPLCONFIGDIR',str(ROOT/'runtime/matplotlib'))
EMERGENCY_LABELS={'ambulance':'Ambulance','police':'Police','police car':'Police',
    'fire engine':'Fire engine','fire truck':'Fire engine','firetruck':'Fire engine'}

def load_config(path):
    from .session import validate_session
    return validate_session(json.loads(Path(path).read_text()))

def signal_at(timeline,timestamp):
    state='unknown'
    for when,value in timeline:
        if when>timestamp: break
        state=value
    return state

def rect_valid(rect):
    return isinstance(rect,list) and len(rect)==4 and all(type(v) in (int,float) and math.isfinite(v) and 0<=v<=1 for v in rect) and rect[0]<rect[2] and rect[1]<rect[3]

def read_signals(path):
    with open(path,newline='') as file:
        rows=[(float(r['seconds']),r['state'].strip().lower()) for r in csv.DictReader(file)]
    if any(not math.isfinite(t) or t<0 or s not in ('red','yellow','green','unknown') for t,s in rows): raise ValueError('Invalid signal timeline')
    if any(rows[i][0]>=rows[i+1][0] for i in range(len(rows)-1)): raise ValueError('Signal times must be strictly increasing')
    return rows

def crop_rect(frame,rect):
    h,w=frame.shape[:2]
    a,b,c,d=rect
    return frame[int(b*h):int(d*h),int(a*w):int(c*w)]

def signal_color(frame,rect):
    """HSV color heuristic for a tightly calibrated signal lamp, not a learned detector."""
    import cv2
    import numpy as np
    crop=crop_rect(frame,rect)
    if crop.size==0: return 'unknown'
    hsv=cv2.cvtColor(crop,cv2.COLOR_BGR2HSV)
    ranges={'red':[(0,10),(170,179)],'yellow':[(15,38)],'green':[(40,95)]}
    scores={}
    for name,intervals in ranges.items():
        mask=np.zeros(hsv.shape[:2],dtype=np.uint8)
        for low,high in intervals:
            mask|=cv2.inRange(hsv,np.array([low,100,140]),np.array([high,255,255]))
        scores[name]=float(np.count_nonzero(mask))/mask.size
    ranked=sorted(scores,key=scores.get,reverse=True)
    return ranked[0] if scores[ranked[0]]>=.025 and scores[ranked[0]]>2*scores[ranked[1]] else 'unknown'

class EmergencyGate:
    """Require repeated observations; do not renew indefinitely for a parked vehicle."""
    def __init__(self,frames=3):
        self.frames=frames
        self.items={}
    def update(self,observations,timestamp):
        active=set(observations)
        events=[]
        for key in list(self.items):
            if key not in active:
                self.items[key]['count']=0
                if timestamp-self.items[key]['last']>2:
                    del self.items[key]
        for key in active:
            item=self.items.setdefault(key,{'count':0,'last':timestamp,'latched':False})
            item['count']+=1;item['last']=timestamp
            if item['count']>=self.frames and not item['latched']:
                item['latched']=True;events.append(key)
        return events

def plate_text(results):
    """Join OCR fragments in reading order, including two-line number plates.

    Confidence is the weakest accepted fragment, not a calibrated accuracy.
    """
    fragments=[]
    for box,text,score in results:
        text=re.sub('[^A-Z0-9]','',text.upper())
        if text and score>=.35:
            xs=[float(p[0]) for p in box];ys=[float(p[1]) for p in box]
            fragments.append((min(xs),sum(ys)/len(ys),max(ys)-min(ys),text,float(score)))
    rows=[]
    for fragment in sorted(fragments,key=lambda f:f[1]):
        row=next((r for r in rows if abs(r[0][1]-fragment[1])<=max(r[0][2],fragment[2])*.5),None)
        if row is None: rows.append([fragment])
        else: row.append(fragment)
    ordered=[f for row in rows for f in sorted(row,key=lambda f:f[0])]
    text=''.join(f[3] for f in ordered)
    if not 5<=len(text)<=16: return None,None
    return text,min(f[4] for f in ordered)


class PlateReader:
    def __init__(self,plate_model=None):
        import easyocr
        self.reader=easyocr.Reader(['en'],gpu=False,model_storage_directory=str(ROOT/'runtime/easyocr'),download_enabled=False,verbose=False)
        self.model=plate_model
    def read(self,vehicle):
        import cv2
        if not vehicle.size: return None,None,None
        h,w=vehicle.shape[:2]
        candidates=[]
        if self.model is not None:
            result=self.model.predict(vehicle,conf=.35,verbose=False)[0]
            if result.boxes is not None:
                candidates=[tuple(map(int,b)) for b in result.boxes.xyxy.cpu().tolist()]
        else:
            # Baseline plate localization for demo footage; model-based localization is preferable.
            gray=cv2.cvtColor(vehicle,cv2.COLOR_BGR2GRAY)
            edges=cv2.Canny(cv2.bilateralFilter(gray,9,75,75),60,180)
            contours,_=cv2.findContours(edges,cv2.RETR_LIST,cv2.CHAIN_APPROX_SIMPLE)
            for contour in sorted(contours,key=cv2.contourArea,reverse=True)[:50]:
                x,y,cw,ch=cv2.boundingRect(contour)
                if cw>=35 and ch>=10 and 1.7<=cw/ch<=6.5 and .005<=cw*ch/(w*h)<=.35:
                    candidates.append((x,y,x+cw,y+ch))
            candidates=candidates[:8]
        best=(None,None,None)
        for a,b,c,d in candidates:
            crop=vehicle[max(0,b):min(h,d),max(0,a):min(w,c)]
            if not crop.size: continue
            crop=cv2.resize(crop,None,fx=2,fy=2)
            text,score=plate_text(self.reader.readtext(crop,allowlist='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789',paragraph=False))
            if text and (best[1] is None or score>best[1]):
                best=(text,score,crop)
        return best

def model_path(value):
    path=Path(value)
    if not path.is_file(): path=MODELS/path.name
    if not path.is_file(): raise ValueError(f'Model {value} is missing. Run scripts/download_models.py or add a trusted checkpoint to runtime/models.')
    return str(path)
