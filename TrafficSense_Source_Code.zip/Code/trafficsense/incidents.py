"""Geometry and temporal incident rules; no vision-library dependency."""
import math

DISPLAY_NAMES={'North':'Front','East':'Right','South':'Back','West':'Left'}
ALIASES={**{k:k for k in DISPLAY_NAMES},**{v:k for k,v in DISPLAY_NAMES.items()}}
KINDS=('red_light','crossing_obstruction','no_helmet')

def approach_name(value):
    if value not in ALIASES: raise ValueError('Approach must be Front, Right, Back or Left')
    return ALIASES[value]

def inside(point,polygon):
    x,y=point;result=False
    for a,b in zip(polygon,polygon[1:]+polygon[:1]):
        cross=(b[0]-a[0])*(y-a[1])-(b[1]-a[1])*(x-a[0])
        if abs(cross)<1e-9 and min(a[0],b[0])-1e-9<=x<=max(a[0],b[0])+1e-9 and min(a[1],b[1])-1e-9<=y<=max(a[1],b[1])+1e-9: return True
        if (a[1]>y)!=(b[1]>y) and x<(b[0]-a[0])*(y-a[1])/(b[1]-a[1])+a[0]: result=not result
    return result

class ObstructionDetector:
    """Require a vehicle to remain nearly stationary on the marked crossing."""
    def __init__(self,polygon,seconds=3,movement=.025,max_gap=1.5):
        self.polygon,self.seconds,self.movement,self.max_gap=polygon,seconds,movement,max_gap
        self.tracks={}
    def update(self,identity,point,timestamp):
        for key in list(self.tracks):
            if timestamp-self.tracks[key]['last']>self.max_gap: del self.tracks[key]
        if not inside(point,self.polygon):
            self.tracks.pop(identity,None);return False
        item=self.tracks.get(identity)
        if item is None or math.dist(point,item['anchor'])>self.movement:
            emitted=item['emitted'] if item else False
            self.tracks[identity]={'anchor':point,'since':timestamp,'last':timestamp,'emitted':emitted}
            return False
        item['last']=timestamp
        if not item['emitted'] and timestamp-item['since']>=self.seconds:
            item['emitted']=True;return True
        return False

class Confirmation:
    def __init__(self,frames=3,gap=1.5): self.frames,self.gap,self.items=frames,gap,{}
    def update(self,identity,positive,timestamp):
        for key in list(self.items):
            if timestamp-self.items[key]['last']>self.gap: del self.items[key]
        if not positive:
            if identity in self.items: self.items[identity]['count']=0
            return False
        item=self.items.setdefault(identity,{'last':timestamp,'count':0,'emitted':False})
        item['last']=timestamp;item['count']+=1
        if item['count']>=self.frames and not item['emitted']:
            item['emitted']=True;return True
        return False


def rider_for_head(head,people,motorcycles):
    """Return a unique (rider ID, bike ID); ambiguous associations remain unknown."""
    hx,hy=(head[0]+head[2])/2,(head[1]+head[3])/2
    candidates=[]
    for person_id,p in people:
        ph=p[3]-p[1];pw=p[2]-p[0]
        if ph<=0 or pw<=0 or not (p[0]<=hx<=p[2] and p[1]<=hy<=p[1]+.4*ph): continue
        for bike_id,b in motorcycles:
            bw,bh=b[2]-b[0],b[3]-b[1]
            overlap=max(0,min(p[2],b[2])-max(p[0],b[0]))
            if bw>0 and bh>0 and overlap/min(pw,bw)>=.25 and p[1]<b[1]+.5*bh and b[1]-.3*bh<=p[3]<=b[3]+.2*bh:
                candidates.append((person_id,bike_id))
    return candidates[0] if len(candidates)==1 else None


def helmet_status(person_id,bike_id,people,motorcycles,heads,threshold=.65):
    """Explicit bare head required. No detection or conflicting helmet = uncertain."""
    bare=[];protected=[]
    for label,score,box in heads:
        if rider_for_head(box,people,motorcycles)!=(person_id,bike_id): continue
        if label=='helmet' and score>=.35: protected.append(score)
        if label=='bare_head' and score>=threshold and min(box[2]-box[0],box[3]-box[1])>=12: bare.append(score)
    if protected: return ('helmet',max(protected)) if not bare else ('uncertain',None)
    return ('no_helmet',max(bare)) if bare else ('uncertain',None)
