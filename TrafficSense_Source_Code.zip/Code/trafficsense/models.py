"""Pretrained deployment profile and lightweight offline file readiness checks."""
from pathlib import Path

PRETRAINED = {
    'vehicle_model': 'yolo11n.pt',
    'emergency_model': 'emergency-world.pt',
    'helmet_model': 'helmet-world.pt',
    'plate_model': None,
    'ocr': True,
}


def model_inventory(root):
    root = Path(root)
    items = {}
    for role in ('vehicle', 'emergency', 'helmet'):
        name = PRETRAINED[role+'_model']
        path = root/'models'/name
        items[role] = {'file': name, 'present': path.is_file() and path.stat().st_size > 0,
                       'experimental': role in ('emergency', 'helmet')}
    files = ['craft_mlt_25k.pth', 'english_g2.pth']
    items['ocr'] = {'files': files, 'present': all((root/'easyocr'/name).is_file() and (root/'easyocr'/name).stat().st_size > 0 for name in files)}
    return {'profile': dict(PRETRAINED), 'components': items,
            'files_ready': all(item['present'] for item in items.values()),
            'status_scope': 'File availability only; inference readiness is reported by session capabilities.',
            'plate_localization': 'Contour fallback until a dedicated plate checkpoint is supplied.',
            'accuracy': 'Not measured on real intersection footage.'}
