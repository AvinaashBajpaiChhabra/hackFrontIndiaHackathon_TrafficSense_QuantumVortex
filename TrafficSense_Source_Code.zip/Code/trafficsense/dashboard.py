"""Compatibility API for the user's unchanged TrafficSense.html dashboard."""
import json
import math
import uuid
from pathlib import Path
from email.parser import BytesParser
from .incidents import approach_name, DISPLAY_NAMES
from .models import PRETRAINED
from .session import validate_session

ROADS = ('Front', 'Right')
GEOMETRY = [
    {'key': 'stop', 'label': 'Stop line', 'points': 2, 'closed': False},
    {'key': 'traffic', 'label': 'Traffic line', 'points': 2, 'closed': False},
    {'key': 'pedestrian', 'label': 'Pedestrian crossing', 'points': 4, 'closed': True},
]
TYPES = {'red_light': 'Red-light crossing', 'crossing_obstruction': 'Crossing obstruction', 'no_helmet': 'Possible no helmet'}
STATUSES = {'needs_review': 'Needs review', 'confirmed': 'Confirmed', 'dismissed': 'Dismissed'}


def markings_source(markings):
    points = {}
    for schema in GEOMETRY:
        key = schema['key']
        values = markings.get(key) if isinstance(markings, dict) else None
        if not isinstance(values, list) or len(values) != schema['points']:
            raise ValueError(f"{key}: mark {schema['points']} points")
        if any(not isinstance(p, dict) or any(type(p.get(k)) not in (int, float) or not math.isfinite(p[k]) or not 0 <= p[k] <= 1 for k in ('x', 'y')) for p in values):
            raise ValueError('Calibration coordinates must be finite numbers between 0 and 1')
        points[key] = [[p['x'], p['y']] for p in values]
    a, b = points['stop']
    upstream = [sum(p[i] for p in points['traffic']) / 2 for i in (0, 1)]
    side = (b[0]-a[0])*(upstream[1]-a[1]) - (b[1]-a[1])*(upstream[0]-a[0])
    if abs(side) < .0001:
        raise ValueError('Place the traffic line upstream of the stop line, not on it')
    region = points['stop'] + points['traffic']
    xs, ys = [p[0] for p in region], [p[1] for p in region]
    return {'roi': [min(xs), min(ys), max(xs), max(ys)], 'stop_line': points['stop'],
            'direction': -1 if side > 0 else 1, 'crosswalk': points['pedestrian'], 'signal_roi': None}


def counting_source(geometry):
    if not isinstance(geometry,dict): raise ValueError('Counting geometry must be an object')
    region=geometry.get('region');line=geometry.get('line');direction=geometry.get('direction',1)
    # Reuse normalized polygon, segment and direction validation.
    checked=validate_session({'require_four':False,'sources':[{'approach':'North',
        'roi':[0,0,1,1],'stop_line':line,'direction':direction,'crosswalk':region}]})['sources'][0]
    if region is None: raise ValueError('Mark the approaching carriageway polygon')
    xs,ys=zip(*region)
    return {'roi':[min(xs),min(ys),max(xs),max(ys)],'stop_line':checked['stop_line'],
        'direction':direction,'count_region':region,'crosswalk':None,'signal_roi':None,'count_only':True}


def receive_video(handler, directory, limit):
    """Stream the single FormData video part; bound headers, payload and trailer."""
    from email.message import Message
    content_type = Message(); content_type['content-type'] = handler.headers.get('Content-Type', '')
    boundary = content_type.get_param('boundary')
    if content_type.get_content_type() != 'multipart/form-data' or not boundary or len(boundary) > 70:
        raise ValueError('Expected multipart/form-data video upload')
    try: marker = b'--' + boundary.encode('ascii')
    except UnicodeEncodeError as exc: raise ValueError('Invalid multipart boundary') from exc
    remaining = int(handler.headers.get('Content-Length', 0))
    if not 0 < remaining <= limit + 16384:
        raise ValueError('Video upload exceeds 500 MB')
    def line():
        nonlocal remaining
        value = handler.rfile.readline(min(8193, remaining))
        remaining -= len(value)
        if not value or len(value) > 8192: raise ValueError('Invalid multipart header')
        return value
    if line().rstrip(b'\r\n') != marker: raise ValueError('Invalid multipart opening')
    headers = b''
    while True:
        value = line()
        if value == b'\r\n': break
        headers += value
        if len(headers) > 8192: raise ValueError('Multipart headers too large')
    part = BytesParser().parsebytes(headers + b'\r\n')
    filename = part.get_filename() or ''
    extension = Path(filename).suffix.lower()
    if part.get_param('name', header='content-disposition') != 'video' or extension not in ('.mp4', '.avi', '.mov', '.mkv', '.webm'):
        raise ValueError('Choose a supported video file')
    target = Path(directory) / (uuid.uuid4().hex + extension)
    delimiter = b'\r\n' + marker
    tail = b''; total = 0; ended = False
    try:
        with target.open('wb') as output:
            while remaining:
                chunk = handler.rfile.read(min(1048576, remaining))
                if not chunk: raise ValueError('Incomplete upload')
                remaining -= len(chunk); tail += chunk
                position = tail.find(delimiter)
                if position >= 0:
                    if remaining > 4: raise ValueError('Only one video part is supported')
                    if remaining:
                        ending = handler.rfile.read(remaining)
                        if len(ending) != remaining: raise ValueError('Incomplete upload')
                        tail += ending; remaining = 0
                    if tail[position+len(delimiter):].strip(b'\r\n') != b'--':
                        raise ValueError('Only one video part is supported')
                    payload = tail[:position]; ended = True
                else:
                    keep = len(delimiter) + 4
                    if len(tail) <= keep: continue
                    payload, tail = tail[:-keep], tail[-keep:]
                total += len(payload)
                if total > limit: raise ValueError('Video upload exceeds 500 MB')
                output.write(payload)
                if ended: break
        if not ended or not total: raise ValueError('Incomplete or empty video upload')
        return target, Path(filename.replace('\\', '/')).name
    except Exception:
        target.unlink(missing_ok=True)
        raise


class Dashboard:
    def __init__(self, app):
        self.app = app
        self.saved = {}
        self.file = app.runtime/'dashboard-calibration.json'
        self.inputs_file=app.runtime/'dashboard-inputs.json'
        try:
            for road,preview in json.loads(self.inputs_file.read_text()).items():
                if road in ROADS and isinstance(preview.get('source'),str) and Path(preview['source']).is_file() and (app.runtime/'previews'/(approach_name(road)+'.jpg')).is_file():
                    app.previews[approach_name(road)]=preview
        except (OSError,ValueError,TypeError,AttributeError): pass
        try:
            saved = json.loads(self.file.read_text())
            for road, item in saved.items():
                if road not in ROADS: continue
                preview = item['preview']; source = preview['source']
                if isinstance(source, str) and not Path(source).is_file(): continue
                if not (app.runtime/'previews'/(approach_name(road)+'.jpg')).is_file(): continue
                counting_source(item['counting']) if 'counting' in item else markings_source(item['markings'])
                self.saved[road] = item
                app.previews[approach_name(road)] = dict(preview)
        except (OSError, ValueError, KeyError, TypeError):
            self.saved = {}

    def road(self, value):
        title = str(value).title()
        if title not in ROADS: raise ValueError('This dashboard uses Front and Right')
        return title

    def invalidate(self, road):
        self.saved.pop(self.road(road), None)
        self.persist()

    def persist(self):
        temp = self.file.with_suffix('.tmp')
        temp.write_text(json.dumps(self.saved, indent=2))
        temp.replace(self.file)
        inputs={road:dict(self.app.previews[approach_name(road)]) for road in ROADS if approach_name(road) in self.app.previews}
        temp=self.inputs_file.with_suffix('.tmp')
        temp.write_text(json.dumps(inputs,indent=2));temp.replace(self.inputs_file)

    def calibrate(self, road, markings, signal_roi=None):
        road = self.road(road); name = approach_name(road)
        preview = self.app.previews.get(name)
        if not preview: raise ValueError('Upload a video for this road before calibration')
        source = dict(markings_source(markings), approach=name, source=preview['source'])
        source['signal_roi']=signal_roi
        validate_session({'sources': [source], 'require_four': False})
        with self.app.lifecycle:
            self.app.stop_video()
            self.saved[road] = {'markings': markings, 'preview': dict(preview), 'signal_roi':signal_roi}
            self.persist()
        return {'ok': True, 'road': road}

    def calibrate_counting(self,road,geometry):
        road=self.road(road);preview=self.app.previews.get(approach_name(road))
        if not preview: raise ValueError('Upload this road video first')
        counting_source(geometry)
        with self.app.lifecycle:
            self.app.stop_video()
            self.saved[road]={'counting':geometry,'preview':dict(preview)}
            self.persist()
        return {'ok':True,'road':road,'mode':'directional passage counting'}

    def configuration(self):
        sources = []; complete=True
        for road in ROADS:
            item = self.saved.get(road); preview = self.app.previews.get(approach_name(road))
            if not preview:
                complete=False
                continue
            if not item or not preview or item['preview']['preview_id'] != preview['preview_id']:
                complete=False
                # This placeholder line satisfies the source schema but is never
                # used or drawn: uncalibrated inputs perform counting only.
                source=dict(preview,approach=approach_name(road),roi=[0,0,1,1],
                            stop_line=[[0,1],[1,1]],direction=1,crosswalk=None,signal_roi=None,count_only=True)
            elif 'counting' in item:
                complete=False
                source=dict(counting_source(item['counting']),**preview,approach=approach_name(road))
            else:
                source=dict(markings_source(item['markings']), **preview, approach=approach_name(road))
                source['signal_roi']=item.get('signal_roi')
            sources.append(source)
        if not sources: raise ValueError('Upload a video in live mode first; demo uploads stay in the browser')
        config=dict(PRETRAINED,sources=sources,require_four=False,analysis_only=not complete,
                    junction='Pitampura Intersection',analysis_fps=5)
        if not complete:config.update(emergency_model=None,helmet_model=None,ocr=False)
        try:
            scenario=json.loads((self.app.runtime/'demo-scenario.json').read_text())
            if scenario.get('enabled') is True and scenario.get('preview_id')==self.app.previews.get('East',{}).get('preview_id'):
                config['demo_scenario']={'approach':'East','duration':15}
        except (OSError,ValueError,AttributeError): pass
        return validate_session(config)

    def control(self, action):
        app = self.app
        if action == 'start':
            if app.pipeline_state in ('loading', 'processing'):
                with app.lock: app.running = True
            else: app.start_video(self.configuration())
        elif action == 'pause':
            if app.running: app.action('pause')
        elif action in ('stop', 'emergency-stop'):
            with app.lifecycle: app.stop_video()
        else: raise ValueError('Unknown control action')
        return self.snapshot()

    def snapshot(self):
        app = self.app; raw = app.snapshot(); cameras = []
        for road in ROADS:
            name = approach_name(road); camera = raw['cameras'][name]; preview = app.previews.get(name)
            frame = (f'/api/frame.jpg?approach={name}&t={camera["video_time"]}' if camera['frame_ready']
                     else preview['url']+'&v='+preview['preview_id'] if preview else None)
            cameras.append({'road': road, 'count': camera.get('total_passed'), 'visibleCount':camera['count'], 'signal': camera['observed'],
                'status': camera['error'] or camera['status'], 'frame': frame, 'detections': [],
                'timestamp': f"Video {camera['video_time']:.1f}s"})
        controller = raw['controller']; recommendation = None
        if raw['control_ready'] and controller['stage'] == 'green':
            road = DISPLAY_NAMES[controller['active']]
            recommendation = {'road': road, 'duration': controller['target_green'],
                'waiting': raw['wait'][controller['active']],
                'reason': controller['priority']['reason'] if controller['priority'] else 'Vehicle density and waiting demand; bounded green timing.'}
        simulated=raw.get('demo_emergency')
        demo_enabled=bool((raw.get('config') or {}).get('demo_scenario'))
        demo_fresh=raw['running'] and raw['pipeline_state']=='processing' and any(c['status']=='processing' and c['age'] is not None and c['age']<5 for c in raw['cameras'].values())
        if demo_enabled and demo_fresh:
            if simulated:
                recommendation={'road':DISPLAY_NAMES[simulated['approach']],'duration':simulated['duration'],
                    'waiting':0,'reason':'SIMULATED ambulance priority; advisory demo only','simulated':True}
            else:
                available=[(n,c) for n,c in raw['cameras'].items() if c['status']=='processing' and c['count'] is not None and c['age'] is not None and c['age']<5]
                if available:
                    video_time=max(c['video_time'] for _,c in available)
                    preferred=('North','East')[int(video_time//10)%2]
                    name,camera=next((pair for pair in available if pair[0]==preferred),available[0])
                    recommendation={'road':DISPLAY_NAMES[name],'duration':10,
                        'waiting':0,'reason':'Alternating demo phase; ambulance priority overrides; advisory only','simulated':True}
        incidents = [{'id': str(e['id']), 'time': e.get('capture_time') or f"Video {e.get('video_time') or 0:.2f}s", 'location': e.get('place'),
            'road': DISPLAY_NAMES.get(e['approach'], e['approach']), 'type': TYPES.get(e.get('violation_type'), e.get('violation_type')),
            'plate': e.get('plate') or '', 'status': STATUSES.get(e.get('review_status'), 'Needs review'),
            'image': e.get('evidence'), 'vehicleCrop': e.get('vehicle_image'), 'plateCrop': e.get('plate_image')}
            for e in raw['events']]
        h = raw['hardware']; ack = h.get('acknowledged')
        known = bool(h['connected'] and isinstance(ack, str) and len(ack) == 4 and all(c in 'RYG' for c in ack) and sum(c != 'R' for c in ack) <= 1)
        hardware = {'connected': known, 'ack': ack if known else None, 'signals': dict(zip(('Front','Right','Back','Left'), [{'R':'red','Y':'yellow','G':'green'}[c] for c in ack])) if known else dict.fromkeys(('Front','Right','Back','Left'), 'unknown')}
        return {'cameras': cameras, 'recommendation': recommendation, 'incidents': incidents,
            'hardware': hardware, 'fps': min((c['fps'] for c in raw['cameras'].values() if c['status'] == 'processing'), default=None),
            'model': 'YOLO11 + ByteTrack; experimental emergency/head detectors' if raw['capabilities']['vehicle'] else 'Not loaded',
            'analysisState': 'Paused' if raw['pipeline_state'] in ('loading','processing') and not raw['running'] else {'processing':'Running','loading':'Loading','finished':'Finished','stopped':'Stopped','idle':'Ready'}.get(raw['pipeline_state'],raw['pipeline_state']),
            'calibrations': {road: item['markings'] for road,item in self.saved.items() if 'markings' in item},
            'clearancePhase': {'yellow':'Yellow clearance','all_red':'All-red clearance','green':'Green phase'}[controller['stage']] if raw['control_ready'] else raw['safety_reason'],
            'priorityRequests': [{'road':DISPLAY_NAMES[e['approach']], 'status':e['state']} for e in raw['priority_queue']],
            'emergencies': [{'road':DISPLAY_NAMES[e['approach']],'type':'Simulated ambulance','confidence':None,'intersection':'Pitampura Intersection','status':'Simulated · Priority active' if simulated and demo_fresh else 'Simulated · Priority completed','simulated':True,'image':e.get('image'),'videoTime':e['started']} for e in raw.get('demo_history',[])] + [{'road':DISPLAY_NAMES[e['approach']], 'type':e['vehicle'], 'confidence':e.get('confidence'), 'intersection':(raw['config'] or {}).get('junction'), 'status':e['state']} for e in raw['priority_events'] if e['source'].startswith('AI')],
            'demoScenario':demo_enabled,'capabilities': raw['capabilities'], 'safetyReason': raw['safety_reason']}
