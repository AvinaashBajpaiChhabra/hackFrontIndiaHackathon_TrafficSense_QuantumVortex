"""Deterministic traffic logic, independent of computer vision and the UI."""
from dataclasses import dataclass

APPROACHES = ('North', 'East', 'South', 'West')

@dataclass
class Timing:
    min_green: float = 10
    max_green: float = 35
    yellow: float = 3
    all_red: float = 2
    max_wait: float = 90

    def __post_init__(self):
        if not (0 < self.min_green <= self.max_green and self.yellow > 0 and self.all_red > 0 and self.max_wait > 0):
            raise ValueError('Invalid signal timing bounds')

class Controller:
    """One approach green at a time; recommendations only, no hardware control."""
    def __init__(self, timing=None, enabled=None):
        self.timing = timing or Timing()
        names = tuple(APPROACHES if enabled is None else enabled)
        if not names or len(set(names)) != len(names) or any(n not in APPROACHES for n in names):
            raise ValueError('Enable at least one unique valid approach')
        self.enabled = tuple(APPROACHES.index(n) for n in names)
        self.active = self.enabled[0]
        self.stage = 'green'
        self.elapsed = 0.0
        self.target = self.timing.min_green
        self.wait = [0.0] * 4
        self.next_active = self.enabled[1 % len(self.enabled)]
        self.priority = None
        self.priority_remaining = 0.0
        self.priority_reason = None
        self.pedestrian_blocked = False
        self.pedestrian_requested = 0.0
        self.pedestrian_remaining = 0.0

    def request_priority(self, approach, seconds=20, reason="Operator request"):
        if approach not in APPROACHES or APPROACHES.index(approach) not in self.enabled or not 1 <= seconds <= 30:
            raise ValueError("Priority needs a valid approach and a 1–30 second lease")
        self.priority = APPROACHES.index(approach)
        self.priority_remaining = float(seconds)
        self.priority_reason = reason

    def cancel_priority(self):
        self.priority, self.priority_remaining, self.priority_reason = None, 0.0, None

    def request_pedestrian(self, seconds=10):
        if not 5 <= seconds <= 30:
            raise ValueError("Pedestrian phase must be 5–30 seconds")
        self.pedestrian_requested = float(seconds)

    def advance(self, dt, counts):
        if len(counts) != 4 or any(c < 0 for c in counts) or dt < 0:
            raise ValueError('Expected four nonnegative counts and a nonnegative time step')
        t = self.timing
        # Bounded substeps retain yellow/all-red clearance even after a delayed tick.
        remaining = dt
        while remaining > 1e-9:
            step = min(0.1, remaining)
            remaining -= step
            for i in range(4):
                self.wait[i] = 0 if i not in self.enabled or self.stage == 'green' and i == self.active else self.wait[i] + step
            self.elapsed += step
            self.pedestrian_remaining = max(0, self.pedestrian_remaining-step)
            if self.priority is not None:
                self.priority_remaining -= step
                if self.priority_remaining <= 0:
                    self.cancel_priority()
            if self.stage == 'green':
                self.target = max(t.min_green, min(t.max_green, t.min_green + 1.3 * counts[self.active]))
                overdue = any(self.wait[i] >= t.max_wait and counts[i] > 0 for i in self.enabled if i != self.active)
                priority_switch = self.priority is not None and self.priority != self.active
                pedestrian_switch = self.pedestrian_requested > 0 and self.priority is None and self.elapsed >= t.min_green
                normal_switch = self.priority is None and (self.elapsed + 1e-8 >= self.target or (overdue and self.elapsed + 1e-8 >= t.min_green))
                if priority_switch or normal_switch or pedestrian_switch or self.pedestrian_blocked:
                    self.stage, self.elapsed = 'yellow', 0.0
            elif self.stage == 'yellow' and self.elapsed + 1e-8 >= t.yellow:
                self.stage, self.elapsed = 'all_red', 0.0
                candidates = [i for i in self.enabled if i != self.active] or [self.active]
                overdue = [i for i in candidates if counts[i] > 0 and self.wait[i] >= t.max_wait]
                self.next_active = max(overdue, key=lambda i: self.wait[i]) if overdue else max(candidates, key=lambda i: counts[i] * 2 + self.wait[i] / 5)
            elif self.stage == 'all_red' and self.elapsed + 1e-8 >= t.all_red:
                if self.pedestrian_requested > 0:
                    self.pedestrian_remaining = self.pedestrian_requested
                    self.pedestrian_requested = 0.0
                elif not self.pedestrian_blocked and self.pedestrian_remaining <= 1e-8:
                    self.active = self.priority if self.priority is not None else self.next_active
                    self.stage, self.elapsed = 'green', 0.0

    def snapshot(self):
        duration = {'green': self.target, 'yellow': self.timing.yellow, 'all_red': self.timing.all_red}[self.stage]
        remaining = max(0, duration-self.elapsed, self.pedestrian_remaining)
        return {'pedestrian': {'occupied': self.pedestrian_blocked, 'walk': self.pedestrian_remaining > 0, 'remaining': round(self.pedestrian_remaining,1), 'requested': self.pedestrian_requested > 0}, 'priority': None if self.priority is None else {'approach': APPROACHES[self.priority], 'remaining': round(self.priority_remaining, 1), 'reason': self.priority_reason}, 'active': APPROACHES[self.active], 'stage': self.stage,
                'remaining': round(remaining, 1),
                'target_green': round(self.target, 1),
                'signals': {name: (self.stage if i == self.active and self.stage != 'all_red' else 'red') for i, name in enumerate(APPROACHES)}}

class CrossingDetector:
    """Directed segment crossing with track deduplication and stale-track expiry."""
    def __init__(self, line, direction=1, ttl=3):
        self.a, self.b = line
        if self.a == self.b or direction not in (-1, 1):
            raise ValueError('A nonzero line and direction -1 or 1 are required')
        self.direction, self.ttl = direction, ttl
        self.previous = {}
        self.reported = set()

    def side(self, p):
        return ((self.b[0]-self.a[0])*(p[1]-self.a[1]) - (self.b[1]-self.a[1])*(p[0]-self.a[0])) * self.direction

    def update(self, track_id, point, timestamp, signal):
        stale = [k for k, (_, when) in self.previous.items() if timestamp - when > self.ttl]
        for key in stale:
            self.previous.pop(key)
            self.reported.discard(key)
        old = self.previous.get(track_id)
        self.previous[track_id] = (point, timestamp)
        if old is None or track_id in self.reported:
            return False
        p = old[0]
        before, after = self.side(p), self.side(point)
        if not (before < 0 <= after):
            return False
        fraction = -before / (after - before)
        crossing = (p[0] + fraction*(point[0]-p[0]), p[1] + fraction*(point[1]-p[1]))
        dx, dy = self.b[0]-self.a[0], self.b[1]-self.a[1]
        projection = ((crossing[0]-self.a[0])*dx + (crossing[1]-self.a[1])*dy)/(dx*dx+dy*dy)
        if not 0 <= projection <= 1:
            return False
        self.reported.add(track_id)
        return signal == 'red'

class PassageCounter:
    """Session total of unique tracks crossing a segment, independent of signals."""
    def __init__(self, line, direction=None):
        self.detectors=[CrossingDetector(line,d) for d in ([direction] if direction else [1,-1])]
        self.counted=set()

    @property
    def total(self):
        return len(self.counted)

    def update(self, track_id, point, timestamp):
        crossed=False
        for detector in self.detectors:
            crossed=detector.update(track_id,point,timestamp,'red') or crossed
        if crossed and track_id not in self.counted:
            self.counted.add(track_id)
            return True
        return False
