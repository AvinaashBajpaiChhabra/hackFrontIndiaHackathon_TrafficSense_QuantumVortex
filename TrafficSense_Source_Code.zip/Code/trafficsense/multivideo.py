"""Fair four-source scheduler. Each source owns its YOLO/ByteTrack state."""
import math
import queue
import threading
import time
import uuid
from datetime import datetime,timedelta,timezone
from pathlib import Path
from .core import APPROACHES,CrossingDetector,PassageCounter
from .incidents import DISPLAY_NAMES,ObstructionDetector,Confirmation,inside,helmet_status,rider_for_head
from .vision import PlateReader,EmergencyGate,signal_at,read_signals,signal_color,model_path,EMERGENCY_LABELS

HEAD_LABELS={'helmet':'helmet','motorcycle helmet':'helmet','motorbike helmet':'helmet',
    'bare human head':'bare_head','bare head':'bare_head','no helmet':'bare_head','without helmet':'bare_head','unhelmeted head':'bare_head'}

def normalized_label(label): return str(label).lower().replace('_',' ').replace('-',' ').strip()

def boxes_from(result):
    boxes=result.boxes
    if boxes is None: return []
    ids=boxes.id.int().cpu().tolist() if boxes.id is not None else [None]*len(boxes.xyxy)
    return list(zip(boxes.xyxy.cpu().tolist(),boxes.cls.int().cpu().tolist(),boxes.conf.cpu().tolist(),ids))

class EvidenceWriter:
    def __init__(self,app,reader,stop,session):
        self.app,self.reader,self.stop,self.session=app,reader,stop,session
        self.jobs=queue.Queue(maxsize=16)
        self.thread=threading.Thread(target=self.run,daemon=True);self.thread.start()
    def submit(self,frame,box,event,overlays):
        try:
            with self.app.lock:
                self.jobs.put_nowait((frame.copy(),box,dict(event),overlays))
                self.app.event_jobs+=1
            return True
        except queue.Full:
            # Preserve the incident even under load; never silently invent an OCR read.
            event=dict(event,evidence=None,details=event.get('details','')+' | Evidence queue full; manual review required.')
            self.app.store.add(event)
            return False
    def run(self):
        import cv2
        while True:
            job=self.jobs.get()
            if job is None: self.jobs.task_done();return
            frame,box,event,overlays=job
            try:
                h,w=frame.shape[:2];a,b,c,d=map(int,box)
                a,b,c,d=max(0,a),max(0,b),min(w,c),min(h,d)
                vehicle=frame[b:d,a:c];plate,confidence,plate_crop=None,None,None
                if self.reader and not self.stop.is_set():
                    try: plate,confidence,plate_crop=self.reader.read(vehicle)
                    except Exception as exc: event['details']+=f' | OCR failed: {type(exc).__name__}'
                filename=uuid.uuid4().hex;directory=self.app.runtime/'evidence'
                evidence=frame.copy()
                if overlays.get('line'):
                    points=[(int(p[0]*w),int(p[1]*h)) for p in overlays['line']]
                    cv2.line(evidence,*points,(50,180,255),2)
                if overlays.get('polygon'):
                    import numpy as np
                    cv2.polylines(evidence,[np.array([(int(x*w),int(y*h)) for x,y in overlays['polygon']],dtype='int32')],True,(255,180,50),2)
                cv2.rectangle(evidence,(a,b),(c,d),(30,30,255),3)
                cv2.putText(evidence,f"{DISPLAY_NAMES[event['approach']]} | {event['violation_type']} | {event['video_time']:.2f}s",(12,25),cv2.FONT_HERSHEY_SIMPLEX,.55,(30,30,255),2)
                cv2.putText(evidence,f"{event['place'][:60]} | {plate or 'PLATE UNREAD'}",(12,50),cv2.FONT_HERSHEY_SIMPLEX,.5,(255,255,255),1)
                def save(suffix,image):
                    name=filename+suffix+'.jpg'
                    return '/evidence/'+name if image is not None and image.size and cv2.imwrite(str(directory/name),image) else None
                event.update(plate=plate,confidence=confidence,evidence=save('',evidence),vehicle_image=save('-vehicle',vehicle),plate_image=save('-plate',plate_crop))
                self.app.store.add(event)
            except Exception as exc:
                event.update(evidence=None,details=event.get('details','')+f' | Evidence error: {type(exc).__name__}')
                try: self.app.store.add(event)
                except Exception as save_error:
                    with self.app.lock: self.app.error='Evidence persistence failed: '+str(save_error)
            finally:
                with self.app.lock:
                    if self.app.session_id==self.session: self.app.event_jobs=max(0,self.app.event_jobs-1)
                self.jobs.task_done()
    def finish(self):
        self.jobs.put(None);self.thread.join()


class Camera:
    def __init__(self,source,vehicle_model,config):
        import cv2
        self.s=source;self.name=source['approach'];self.tracker=vehicle_model
        self.cap=cv2.VideoCapture(source['source'])
        if not self.cap.isOpened(): raise ValueError(f'{DISPLAY_NAMES[self.name]}: cannot open input')
        self.is_file=isinstance(source['source'],str) and Path(source['source']).is_file()
        self.fps=self.cap.get(cv2.CAP_PROP_FPS)
        if not math.isfinite(self.fps) or self.fps<=0: self.fps=25
        self.next_index=int(source['offset']*self.fps)
        if self.is_file and self.next_index:
            if not self.cap.set(cv2.CAP_PROP_POS_FRAMES,self.next_index): raise ValueError('Video codec cannot seek to configured offset')
        self.crossing=CrossingDetector(source['stop_line'],source.get('direction',1))
        self.count_line=[[0,.5],[1,.5]] if source.get('count_only') and not source.get('count_region') else source['stop_line']
        self.passage=PassageCounter(self.count_line,None if source.get('count_only') and not source.get('count_region') else source.get('direction',1))
        self.obstruction=ObstructionDetector(source['crosswalk'],source['obstruction_seconds']) if source.get('crosswalk') and not source.get('count_only') else None
        self.helmet=Confirmation(3);self.emergency=EmergencyGate(3);self.signal_history=[]
        self.timeline=read_signals(source['signal_timeline']) if source.get('signal_timeline') else []
        self.status='processing';self.started=time.monotonic()
    def read(self,master):
        if not self.is_file:
            ok,frame=self.cap.read();return ok,frame,time.monotonic()-self.started
        target=int((self.s['offset']+master)*self.fps+1e-6)
        while self.next_index<target:
            if not self.cap.grab(): return False,None,target/self.fps
            self.next_index+=1
        ok,frame=self.cap.read();timestamp=self.next_index/self.fps;self.next_index+=1
        return ok,frame,timestamp


def run_session(app,config,stop):
    cameras=[];writer=None;fatal=None
    try:
        import cv2
        import numpy as np
        from ultralytics import YOLO
        import torch
        # Avoid four independent trackers oversubscribing CPU threads.
        torch.set_num_threads(2)
        vehicle_path=model_path(config['vehicle_model'])
        emergency=YOLO(model_path(config['emergency_model'])) if config.get('emergency_model') else None
        if emergency and not set(normalized_label(n) for n in emergency.names.values()).intersection(EMERGENCY_LABELS): raise ValueError('Emergency checkpoint has no supported emergency classes')
        helmet=YOLO(model_path(config['helmet_model'])) if config.get('helmet_model') else None
        if helmet and not any(HEAD_LABELS.get(normalized_label(n))=='bare_head' for n in helmet.names.values()): raise ValueError('Helmet model needs an explicit no-helmet / bare-head class; absence of a helmet is not enough')
        plate=YOLO(model_path(config['plate_model'])) if config.get('plate_model') else None
        if plate and not any('plate' in normalized_label(n) for n in plate.names.values()): raise ValueError('Choose a plate-specific checkpoint')
        reader=None;ocr_error=None
        if config.get('ocr'):
            try: reader=PlateReader(plate)
            except (ImportError,FileNotFoundError) as exc: ocr_error=str(exc)
        for source in config['sources']:
            if stop.is_set(): return
            model=YOLO(vehicle_path)
            labels={normalized_label(n) for n in model.names.values()}
            if not labels.intersection({'car','truck','bus','motorcycle','motorbike'}): raise ValueError('Vehicle checkpoint has no supported vehicle classes')
            camera=Camera(source,model,config);cameras.append(camera)
        kinds={'emergency_kind':'experimental zero-shot' if config.get('emergency_model') and Path(config['emergency_model']).name=='emergency-world.pt' else 'custom checkpoint',
            'helmet_kind':'experimental zero-shot' if config.get('helmet_model') and Path(config['helmet_model']).name=='helmet-world.pt' else 'custom checkpoint'}
        with app.lock:
            app.capabilities={'vehicle':True,'plate':reader is not None,'ocr_error':ocr_error,'emergency':bool(emergency),'helmet':bool(helmet),**kinds}
            app.pipeline_state='processing';app.status=config['junction']+f' · {len(cameras)} inputs · one controller · typed evidence review'
        writer=EvidenceWriter(app,reader,stop,app.session_id)
        from .demo_scenario import DemoAmbulance
        scenario=DemoAmbulance(**config['demo_scenario']) if config.get('demo_scenario') else None
        session=app.session_id;cycle=0;start=time.monotonic();pause_start=None
        for camera in cameras: camera.started=start
        rate=min(config['analysis_fps'],*(c.fps for c in cameras));max_lag=0
        while not stop.is_set() and any(c.status=='processing' for c in cameras):
            if not app.running:
                if pause_start is None: pause_start=time.monotonic()
                stop.wait(.1);continue
            if pause_start is not None:
                for camera in cameras: camera.emergency=EmergencyGate(3)
                pause_start=None
            cycle_start=time.monotonic();master=cycle/rate;updates={}
            for camera in cameras:
                if stop.is_set(): break
                if camera.status!='processing': continue
                name=camera.name;s=camera.s;started=time.monotonic()
                try:
                    ok,frame,video_time=camera.read(master)
                    if not ok:
                        camera.status='finished'
                        with app.lock:
                            app.cameras[name].update(status='finished',pedestrians=0)
                            app.controller.cancel_priority();app.priority_queue=[]
                        continue
                    h,w=frame.shape[:2];signal='unknown'
                    if camera.timeline: signal=signal_at(camera.timeline,video_time)
                    elif s.get('signal_roi'):
                        raw=signal_color(frame,s['signal_roi']);camera.signal_history=(camera.signal_history+[raw])[-3:]
                        if len(camera.signal_history)==3 and len(set(camera.signal_history))==1: signal=raw
                    result=camera.tracker.track(frame,persist=True,tracker='bytetrack.yaml',conf=config['confidence'],verbose=False,device='cpu')[0]
                    vehicles=[];people=[];motorcycles=[];count=0;pedestrians=0
                    roi=s['roi'];annotated=frame.copy();incidents=[]
                    if not hasattr(camera,'assigned'): camera.assigned={}
                    camera.assigned={i:t for i,t in camera.assigned.items() if video_time-t<3}
                    for box,cls,score,identity in boxes_from(result):
                        if identity is None: continue
                        label=normalized_label(camera.tracker.names[int(cls)])
                        if label=='person': people.append((identity,box));continue
                        if label not in ('car','truck','bus','motorcycle','motorbike','bicycle'): continue
                        point=((box[0]+box[2])/2/w,box[3]/h)
                        in_roi=roi[0]<=point[0]<=roi[2] and roi[1]<=point[1]<=roi[3]
                        if s.get('count_region'):
                            in_roi=in_roi and inside(point,s['count_region'])
                            if not in_roi: continue
                        camera.passage.update(identity,point,video_time)
                        count+=int(in_roi);vehicles.append((identity,box,score,label,point))
                        if label in ('motorcycle','motorbike'): motorcycles.append((identity,box))
                        # The camera represents one approach; only previously upstream tracks may cross its line.
                        if not s.get('count_only') and (in_roi or identity in camera.assigned):
                            camera.assigned[identity]=video_time
                            if camera.crossing.update(identity,point,video_time,signal):
                                incidents.append(('red_light',identity,box,score,'Directed stop-line crossing during observed red.'))
                        if camera.obstruction and camera.obstruction.update(identity,point,video_time):
                            incidents.append(('crossing_obstruction',identity,box,score,f'Ground-contact point remained on marked crossing for {s["obstruction_seconds"]:g}s with limited motion.'))
                        x1,y1,x2,y2=map(int,box);cv2.rectangle(annotated,(x1,y1),(x2,y2),(100,220,140),2)
                        cv2.putText(annotated,f'{DISPLAY_NAMES[name]} ID {identity}',(x1,max(18,y1-6)),cv2.FONT_HERSHEY_SIMPLEX,.45,(255,255,255),1)
                    if s.get('crosswalk') and not s.get('count_only'):
                        pedestrians=sum(inside(((p[0]+p[2])/2/w,p[3]/h),s['crosswalk']) and rider_for_head([p[0],p[1],p[2],p[1]+.3*(p[3]-p[1])],people,motorcycles) is None for _,p in people)
                    helmet_uncertain=0
                    if motorcycles and not s.get('count_only'):
                        heads=[]
                        if helmet:
                            detections=helmet.predict(frame,conf=.35,verbose=False,device='cpu')[0]
                            for box,cls,score,_ in boxes_from(detections):
                                label=HEAD_LABELS.get(normalized_label(helmet.names[int(cls)]))
                                if label: heads.append((label,score,box))
                        for rider_id,person in people:
                            head_region=[person[0],person[1],person[2],person[1]+.3*(person[3]-person[1])]
                            association=rider_for_head(head_region,people,motorcycles)
                            if association is None: continue
                            bike_id=association[1];bike=next(b for i,b in motorcycles if i==bike_id)
                            status,score=helmet_status(rider_id,bike_id,people,motorcycles,heads,config['helmet_confidence'])
                            if status=='uncertain': helmet_uncertain+=1
                            if camera.helmet.update((rider_id,bike_id),status=='no_helmet',video_time):
                                incidents.append(('no_helmet',bike_id,bike,score,f'Explicit uncovered-head detection associated with rider {rider_id} and motorcycle {bike_id}; repeated 3 frames; {kinds["helmet_kind"]}.'))
                    if scenario:
                        eligible=[v for v in vehicles if roi[0]<=v[4][0]<=roi[2] and roi[1]<=v[4][1]<=roi[3]]
                        demo=scenario.update(name,video_time,eligible)
                        if name==scenario.approach:
                            with app.lock:
                                app.demo_emergency=dict(demo) if demo else None
                                if demo and not app.demo_history: app.demo_history.append(dict(demo))
                        if demo:
                            cv2.putText(annotated,'SIMULATED AMBULANCE PRIORITY - DEMO ONLY',(10,48),cv2.FONT_HERSHEY_SIMPLEX,.55,(0,220,255),2)
                            selected=next((v for v in vehicles if v[0]==demo['track_id']),None)
                            if selected:
                                x1,y1,x2,y2=map(int,selected[1]);cv2.rectangle(annotated,(x1,y1),(x2,y2),(0,220,255),3)
                                cv2.putText(annotated,'SIMULATED AMBULANCE',(x1,max(65,y1-10)),cv2.FONT_HERSHEY_SIMPLEX,.55,(0,220,255),2)
                    observations=[];emergency_scores={}
                    if emergency and not s.get('count_only'):
                        detection=emergency.predict(frame,conf=config['emergency_confidence'],verbose=False,device='cpu')[0]
                        for box,cls,score,_ in boxes_from(detection):
                            label=EMERGENCY_LABELS.get(normalized_label(emergency.names[int(cls)]))
                            if not label: continue
                            x1,y1,x2,y2=map(int,box);px,py=(x1+x2)/2/w,y2/h
                            if roi[0]<=px<=roi[2] and roi[1]<=py<=roi[3]:
                                observations.append((name,label))
                                emergency_scores[(name,label)]=max(score,emergency_scores.get((name,label),0))
                            cv2.rectangle(annotated,(x1,y1),(x2,y2),(30,180,255),3)
                            cv2.putText(annotated,label,(x1,max(20,y1-10)),cv2.FONT_HERSHEY_SIMPLEX,.6,(30,180,255),2)
                        for approach,label in camera.emergency.update(observations,video_time): app.request_priority(approach,label,'AI '+kinds['emergency_kind'],confidence=emergency_scores[(approach,label)])
                    for kind,identity,box,score,details in incidents:
                        capture=None
                        if s.get('capture_start'): capture=(datetime.fromisoformat(s['capture_start'])+timedelta(seconds=video_time)).isoformat()
                        event={'timestamp':datetime.now(timezone.utc).isoformat(),'capture_time':capture,'video_time':round(video_time,3),
                            'place':config['junction'],'approach':name,'track_id':f'{session}:{name}:{identity}',
                            'violation_type':kind,'detection_confidence':float(score),'source':'video','session_id':session,
                            'review_status':'needs_review','details':details}
                        writer.submit(frame,box,event,{'line':s['stop_line'],'polygon':s.get('crosswalk')})
                    a,b,c,d=roi;cv2.rectangle(annotated,(int(a*w),int(b*h)),(int(c*w),int(d*h)),(255,180,80),2)
                    if not s.get('count_only'):
                        line=[(int(x*w),int(y*h)) for x,y in s['stop_line']];cv2.line(annotated,*line,(40,40,255) if signal=='red' else (0,200,255),2)
                    if s.get('crosswalk'): cv2.polylines(annotated,[np.array([(int(x*w),int(y*h)) for x,y in s['crosswalk']],dtype='int32')],True,(200,120,255),2)
                    if s.get('signal_roi'):
                        a,b,c,d=s['signal_roi'];cv2.rectangle(annotated,(int(a*w),int(b*h)),(int(c*w),int(d*h)),(220,120,255),2)
                    if s.get('count_region'):
                        import numpy as np
                        cv2.polylines(annotated,[np.array([(int(x*w),int(y*h)) for x,y in s['count_region']],dtype='int32')],True,(80,190,255),2)
                    cv2.line(annotated,*(tuple(int(p[i]*[w,h][i]) for i in (0,1)) for p in camera.count_line),(255,180,50),2)
                    cv2.putText(annotated,f'{DISPLAY_NAMES[name]} | Passed {camera.passage.total} | Visible {count} | {video_time:.2f}s',(10,22),cv2.FONT_HERSHEY_SIMPLEX,.5,(255,255,255),2)
                    target=app.runtime/'frames'/(name+'.jpg');temporary=target.with_name(name+'.next.jpg')
                    if cv2.imwrite(str(temporary),annotated): temporary.replace(target)
                    if scenario and name==scenario.approach and demo:
                        with app.lock:
                            if app.demo_history and not app.demo_history[0].get('image'):
                                evidence_name=f'demo-ambulance-{session}.jpg'
                                if cv2.imwrite(str(app.runtime/'evidence'/evidence_name),annotated):
                                    app.demo_history[0]['image']='/evidence/'+evidence_name
                    now=time.monotonic();previous=app.cameras[name]['last_frame']
                    updates[name]=dict(status='processing',count=count,total_passed=camera.passage.total,observed=signal,video_time=round(video_time,3),
                        last_frame=now,frame_ready=True,fps=round(1/max(.001,now-previous),1) if previous else 0,
                        inference_ms=round((now-started)*1000),pedestrians=int(pedestrians),helmet_uncertain=helmet_uncertain,error=None)
                except Exception as exc:
                    camera.status='error'
                    with app.lock:
                        app.cameras[name].update(status='error',count=None,error=f'{type(exc).__name__}: {exc}',pedestrians=0)
                        app.controller.cancel_priority();app.priority_queue=[]
            with app.lock:
                for name,values in updates.items(): app.cameras[name].update(values)
                app.clock=master;app.sample()
            cycle+=1
            stop.wait(max(0,1/rate-(time.monotonic()-cycle_start)))
        with app.lock:
            app.pipeline_state='finishing';app.status='Finishing captured evidence · hardware all-red'
    except Exception as exc:
        fatal=f'{type(exc).__name__}: {exc}'
        with app.lock: app.error=fatal;app.pipeline_state='error';app.status='Analysis stopped · check model/input configuration'
    finally:
        for camera in cameras: camera.cap.release()
        if writer: writer.finish()
        with app.lock:
            app.controller.cancel_priority();app.priority_queue=[]
            if not fatal:
                app.pipeline_state='stopped' if stop.is_set() else 'finished'
                app.status=config['junction']+(' · analysis stopped' if stop.is_set() else ' · videos finished · evidence saved · last frames retained')
            elif not app.error: app.error=fatal
