"""Four isolated tracking contexts, scheduled at a shared video time."""
import json
import math
from datetime import datetime
from .core import APPROACHES,CrossingDetector
from .incidents import approach_name,DISPLAY_NAMES
from .vision import rect_valid
from .models import PRETRAINED


def validate_session(config):
    c=json.loads(json.dumps(config))
    sources=c.get('sources')
    if not isinstance(sources,list) or not 1<=len(sources)<=4: raise ValueError('Configure four input videos')
    if c.get('require_four',True) and len(sources)!=4: raise ValueError('Front, Right, Back and Left videos are required')
    seen=set();cameras=set()
    for s in sources:
        if 'count_only' in s and type(s['count_only']) is not bool: raise ValueError('count_only must be boolean')
        s['approach']=approach_name(s.get('approach'))
        name=DISPLAY_NAMES[s['approach']]
        if s['approach'] in seen: raise ValueError('Each approach needs its own input')
        seen.add(s['approach'])
        if not rect_valid(s.get('roi')): raise ValueError(f'{name}: mark the vehicle region')
        line=s.get('stop_line')
        if not isinstance(line,list) or len(line)!=2 or any(not isinstance(p,list) or len(p)!=2 for p in line): raise ValueError(f'{name}: mark the stop line')
        if not all(type(v) in (int,float) and math.isfinite(v) and 0<=v<=1 for p in line for v in p): raise ValueError('Stop line coordinates must be normalized')
        CrossingDetector(line,s.get('direction',1))
        if s.get('signal_roi') is not None and not rect_valid(s['signal_roi']): raise ValueError(f'{name}: invalid lamp region')
        if s.get('count_region') is not None:
            validate_session({'require_four':False,'sources':[dict(s,count_region=None,crosswalk=s['count_region'])]})
        polygon=s.get('crosswalk')
        if polygon is not None:
            if not isinstance(polygon,list) or len(polygon)<3 or len(polygon)>12 or any(not isinstance(p,list) or len(p)!=2 for p in polygon): raise ValueError('Crosswalk needs 3–12 polygon points')
            if not all(type(v) in (int,float) and math.isfinite(v) and 0<=v<=1 for p in polygon for v in p): raise ValueError('Invalid crosswalk coordinates')
            area=abs(sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(polygon,polygon[1:]+polygon[:1])))/2
            if area<.0001: raise ValueError('Crosswalk must have positive area')
        for key,default,high in [('offset',0,86400),('obstruction_seconds',3,60)]:
            value=s.get(key,default)
            if type(value) not in (int,float) or not math.isfinite(value) or not 0<=value<=high or (key=='obstruction_seconds' and value<1): raise ValueError(f'Invalid {key}')
            s[key]=float(value)
        capture=s.get('capture_start')
        if capture:
            dt=datetime.fromisoformat(capture)
            if dt.tzinfo is None: raise ValueError('Capture start must include timezone')
        source=s.get('source')
        if source is not None:
            if type(source) not in (str,int) or isinstance(source,str) and not source: raise ValueError('Invalid video source')
            if type(source) is int:
                if not 0<=source<=9 or source in cameras: raise ValueError('Use distinct USB camera indices 0–9')
                if s['offset']: raise ValueError('Live cameras do not support recorded-video offsets')
                cameras.add(source)
        if s.get('pedestrian_signal_roi') is not None and not rect_valid(s['pedestrian_signal_roi']): raise ValueError('Invalid pedestrian crop')
    types={type(s['source']) is int for s in sources if 'source' in s}
    if len(types)>1: raise ValueError('Use either recorded videos or live cameras for all four inputs, not a mixture')
    for key,default,low,high in [('analysis_fps',5,1,15),('stale_seconds',5,2,30),('confidence',.35,.05,1),('emergency_confidence',.65,.1,1),('helmet_confidence',.65,.1,1)]:
        v=c.get(key,default)
        if type(v) not in (int,float) or not math.isfinite(v) or not low<=v<=high: raise ValueError(f'Invalid {key}')
        c[key]=v
    c['junction']=str(c.get('junction','Intersection 01')).strip()[:120]
    if not c['junction']: raise ValueError('Enter a junction/place name')
    for key,default in [(k,v) for k,v in PRETRAINED.items() if k.endswith('_model')]:
        c.setdefault(key,default)
        if c[key] is not None and (not isinstance(c[key],str) or not c[key]): raise ValueError('Invalid model name')
    c.setdefault('ocr',True)
    if 'analysis_only' in c and type(c['analysis_only']) is not bool: raise ValueError('analysis_only must be boolean')
    return c
