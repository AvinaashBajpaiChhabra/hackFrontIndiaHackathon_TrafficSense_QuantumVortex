"""TrafficSense local research prototype."""
