"""Local four-camera application and API. AI and serial hardware stay on the laptop."""
import argparse
import csv
import io
import json
import math
import threading
import time
import uuid
from datetime import datetime,timezone
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse,parse_qs,unquote
from .core import APPROACHES,Controller
from .store import Store,FIELDS
from .hardware import ArduinoBridge,serial_ports
from .incidents import DISPLAY_NAMES,approach_name,KINDS
from .session import validate_session
from .models import model_inventory
from .dashboard import Dashboard, GEOMETRY, STATUSES, receive_video

ROOT=Path(__file__).resolve().parent.parent
RUNTIME=ROOT/'runtime'
MODELS=RUNTIME/'models'
MAX_UPLOAD=500*1024*1024

def camera_state():
    return {n:{'label':DISPLAY_NAMES[n],'status':'not_configured','count':None,'total_passed':None,'observed':'unknown',
        'video_time':0,'fps':0,'last_frame':0,'frame_ready':False,'error':None,'pedestrians':0,'helmet_uncertain':0} for n in APPROACHES}

class TrafficApp:
    def __init__(self,mode='idle',runtime=None):
        self.runtime=Path(runtime) if runtime else RUNTIME
        self.runtime.mkdir(parents=True,exist_ok=True)
        for sub in ('previews','frames','uploads','evidence'): (self.runtime/sub).mkdir(exist_ok=True)
        self.lock=threading.RLock();self.lifecycle=threading.Lock()
        self.store=Store(self.runtime/'traffic.db')
        self.hardware=ArduinoBridge(self.hardware_signals)
        self.worker=None;self.worker_stop=threading.Event()
        self.previews={};self.config=None;self.mode='idle'
        self.reset_state()
        self.restore()
        self.dashboard=Dashboard(self)

    def reset_state(self):
        self.controller=Controller();self.cameras=camera_state()
        self.running=False;self.pipeline_state='idle';self.error=None
        self.status='Add and calibrate four videos to begin.';self.clock=0;self.history=[];self.last_sample=-2
        self.priority_events=[];self.priority_queue=[];self.event_jobs=0;self.demo_emergency=None;self.demo_history=[]
        self.capabilities={'vehicle':False,'plate':False,'emergency':False,'helmet':False}
        self.session_id=None;self.safety_reason='Analysis not started'

    def restore(self):
        file=self.runtime/'last-session.json'
        try:
            config=validate_session(json.loads(file.read_text()))
            for item in config['sources']:
                if isinstance(item.get('source'),str) and Path(item['source']).is_file() and (self.runtime/'previews'/f"{item['approach']}.jpg").is_file():
                    self.previews[item['approach']]={'preview_id':item.get('preview_id') or uuid.uuid4().hex,'source':item['source'],
                        'source_label':item.get('source_label',DISPLAY_NAMES[item['approach']]),'width':item.get('width',900),
                        'height':item.get('height',500),'url':'/api/preview.jpg?approach='+item['approach'],'frame_seconds':item.get('frame_seconds',0)}
            self.config=config
        except (OSError,ValueError,KeyError,TypeError): pass

    def healthy(self):
        if self.pipeline_state!='processing' or not self.running or self.error: return False
        if (self.config or {}).get('analysis_only'): return False
        now=time.monotonic();stale=(self.config or {}).get('stale_seconds',5)
        return all(self.cameras[n]['status']=='processing' and now-self.cameras[n]['last_frame']<stale for n in self.required_approaches())

    def required_approaches(self):
        return tuple(s['approach'] for s in self.config['sources']) if self.config and self.config.get('sources') else APPROACHES

    def hardware_signals(self):
        with self.lock:
            return self.controller.snapshot()['signals'] if self.healthy() else None

    def tick(self,dt):
        with self.lock:
            healthy=self.healthy()
            if not healthy:
                self.safety_reason=('Counting only: upload and calibrate both roads before signal control.' if (self.config or {}).get('analysis_only') else 'All configured inputs must be running and fresh; hardware held all-red.')
                if any(self.cameras[n]['status'] in ('error','finished') for n in self.required_approaches()) or (not self.running):
                    self.controller.cancel_priority();self.priority_queue=[]
                elif all(c['last_frame'] for c in self.cameras.values()):
                    self.controller.cancel_priority();self.priority_queue=[]
                return
            self.safety_reason=None
            self.controller.pedestrian_blocked=any(c['pedestrians']>0 for c in self.cameras.values())
            self.controller.advance(dt,[c['count'] or 0 for c in self.cameras.values()])
            if self.controller.priority is None:
                while self.priority_queue:
                    entry=self.priority_queue.pop(0)
                    if time.monotonic()-entry['queued_at']<60:
                        self.controller.request_priority(entry['approach'],20,entry['vehicle']+' · '+entry['source'])
                        entry['state']='granted';break

    def sample(self):
        if self.clock-self.last_sample>=2:
            self.history.append({'time':round(self.clock,2),'counts':[c['count'] for c in self.cameras.values()]})
            self.history=self.history[-90:];self.last_sample=self.clock

    def snapshot(self):
        with self.lock:
            cameras={k:dict(v) for k,v in self.cameras.items()}
            for c in cameras.values():
                when=c.pop('last_frame');c['age']=round(max(0,time.monotonic()-when),1) if when else None
            return {'mode':self.mode,'running':self.running,'pipeline_state':self.pipeline_state,'status':self.status,'error':self.error,
                'time':round(self.clock,2),'cameras':cameras,'directions':DISPLAY_NAMES,'controller':self.controller.snapshot(),
                'effective_signals':self.hardware_signals() or {n:'red' for n in APPROACHES},'control_ready':self.healthy(),
                'safety_reason':None if self.healthy() else self.safety_reason or 'Inputs unavailable; all-red.',
                'counts':{n:c['count'] for n,c in self.cameras.items()},'history':list(self.history),
                'wait':dict(zip(APPROACHES,[round(x,1) for x in self.controller.wait])),
                'events':self.store.events('video',200),'event_jobs':self.event_jobs,
                'priority_events':[{k:v for k,v in e.items() if k!='queued_at'} for e in self.priority_events],
                'priority_queue':[{k:v for k,v in e.items() if k!='queued_at'} for e in self.priority_queue],
                'demo_emergency':self.demo_emergency,'demo_history':[dict(e) for e in self.demo_history],'capabilities':dict(self.capabilities),'hardware':self.hardware.snapshot(),'config':self.config}

    def request_priority(self,approach,vehicle='Ambulance',source='operator',seconds=20,confidence=None):
        approach=approach_name(approach)
        if confidence is not None and (type(confidence) not in (int,float) or not math.isfinite(confidence) or not 0<=confidence<=1): raise ValueError('Invalid emergency confidence')
        with self.lock:
            if approach not in self.required_approaches(): raise ValueError('Approach is not configured')
            if (self.config or {}).get('analysis_only'): raise ValueError('Priority requires a fully calibrated intersection')
            if not self.running or self.pipeline_state!='processing':
                if source.startswith('AI'): return
                raise ValueError('Start analysis before requesting priority')
            current=self.controller.snapshot()['priority']
            if current and current['approach']==approach: return
            if any(e['approach']==approach and e['vehicle']==vehicle for e in self.priority_queue): return
            event={'approach':approach,'vehicle':vehicle,'source':source,'time':round(self.clock,2),
                'queued_at':time.monotonic(),'state':'queued' if current else 'granted','confidence':confidence}
            if current:
                if len(self.priority_queue)>=12: return
                self.priority_queue.append(event)
            else: self.controller.request_priority(approach,seconds,vehicle+' · '+source)
            self.priority_events.insert(0,event);self.priority_events=self.priority_events[:50]

    def stop_video(self):
        with self.lock: self.running=False;self.worker_stop.set();self.controller.cancel_priority();self.priority_queue=[]
        if self.worker and self.worker.is_alive():
            self.worker.join(timeout=5)
            if self.worker.is_alive(): raise ValueError('Worker is finishing inference/OCR. Wait and retry.')
        with self.lock:
            self.pipeline_state='stopped'
            for c in self.cameras.values():
                if c['status'] in ('processing','loading'): c['status']='stopped'

    def start_video(self,config):
        from .multivideo import run_session
        config=validate_session(config)
        with self.lifecycle:
            self.stop_video()
            with self.lock:
                self.reset_state();self.mode='video';self.config=config;self.running=True
                self.controller=Controller(enabled=[s['approach'] for s in config['sources']])
                self.pipeline_state='loading';self.status=f'Loading models for {len(config["sources"])} inputs…';self.session_id=uuid.uuid4().hex[:12]
                self.worker_stop=threading.Event()
                for s in config['sources']: self.cameras[s['approach']]['status']='loading'
                (self.runtime/'last-session.json').write_text(json.dumps(config,indent=2)+'\n')
            self.worker=threading.Thread(target=run_session,args=(self,config,self.worker_stop),daemon=True);self.worker.start()

    def preview(self,source,approach,seconds=0,label=None):
        import cv2
        approach=approach_name(approach)
        if not math.isfinite(seconds) or not 0<=seconds<=86400: raise ValueError('Invalid preview time')
        if isinstance(source,int) and seconds: raise ValueError('A live camera cannot seek to a recorded frame')
        with self.lifecycle:
            self.stop_video();cap=cv2.VideoCapture(source)
            try:
                if not cap.isOpened(): raise ValueError('Unable to open video/camera')
                if seconds: cap.set(cv2.CAP_PROP_POS_MSEC,seconds*1000)
                ok,frame=cap.read()
                if not ok: raise ValueError('No frame at that time; choose an earlier time')
                target=self.runtime/'previews'/f'{approach}.jpg';temp=target.with_name(approach+'.next.jpg')
                if not cv2.imwrite(str(temp),frame): raise ValueError('Could not save preview')
                temp.replace(target);h,w=frame.shape[:2]
                data={'preview_id':uuid.uuid4().hex,'source':source,'source_label':str(label or DISPLAY_NAMES[approach])[:120],
                    'width':w,'height':h,'frame_seconds':seconds,'url':'/api/preview.jpg?approach='+approach}
                self.previews[approach]=data
                self.cameras[approach]=camera_state()[approach]
                self.cameras[approach]['status']='preview_ready'
                return {k:v for k,v in data.items() if k!='source'}
            finally: cap.release()

    def action(self,name):
        with self.lock:
            if name=='pause':
                if self.pipeline_state not in ('processing','loading'): raise ValueError('No running session')
                self.running=not self.running
                if not self.running: self.controller.cancel_priority();self.priority_queue=[]
            elif name=='cancel-priority': self.controller.cancel_priority();self.priority_queue=[]
            elif name=='pedestrian':
                if not self.healthy(): raise ValueError('All four inputs must be running first')
                self.controller.request_pedestrian()
            else: raise ValueError('Unknown action')


def make_handler(app):
    class Handler(SimpleHTTPRequestHandler):
        def __init__(self,*a,**kw): super().__init__(*a,directory=str(ROOT/'trafficsense/static'),**kw)
        def log_message(self,*args): pass
        def send_bytes(self,body,mime='application/json',status=200):
            self.send_response(status);self.send_header('Content-Type',mime);self.send_header('Content-Length',str(len(body)))
            self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.end_headers()
            try: self.wfile.write(body)
            except (BrokenPipeError,ConnectionResetError): pass
        def json(self,data,status=200): return self.send_bytes(json.dumps(data).encode(),status=status)
        def body(self):
            size=int(self.headers.get('Content-Length',0))
            if not 0<size<1048576: raise ValueError('Expected JSON body under 1MB')
            return json.loads(self.rfile.read(size))
        def do_GET(self):
            parsed=urlparse(self.path);path=parsed.path;q=parse_qs(parsed.query)
            try:
                if path=='/api/state': return self.json(app.snapshot())
                if path=='/api/snapshot': return self.json(app.dashboard.snapshot())
                if path=='/api/calibration/geometry': return self.json(GEOMETRY)
                if path=='/' and (ROOT/'trafficsense/static/TrafficSense.html').is_file():
                    return self.send_bytes((ROOT/'trafficsense/static/TrafficSense.html').read_bytes(),'text/html; charset=utf-8')
                if path=='/api/models': return self.json(model_inventory(ROOT/'runtime'))
                if path=='/api/setup':
                    import importlib.util
                    previews={n:{k:v for k,v in p.items() if k!='source'} for n,p in app.previews.items()}
                    return self.json({'dependencies':{n:bool(importlib.util.find_spec(n)) for n in ('cv2','ultralytics','easyocr','serial')},
                        'ports':serial_ports(),'models':[p.name for p in MODELS.glob('*.pt')],'previews':previews,'config':app.config,'directions':DISPLAY_NAMES})
                if path in ('/api/events','/api/events.csv'):
                    rows=app.store.events('video',10000 if path.endswith('.csv') else 200,kind=q.get('kind',[None])[0],approach=q.get('approach',[None])[0])
                    if path=='/api/events': return self.json(rows)
                    output=io.StringIO();writer=csv.DictWriter(output,fieldnames=['id',*FIELDS]);writer.writeheader()
                    for row in rows:
                        writer.writerow({k:("'"+v if isinstance(v,str) and v.startswith(('=','+','-','@')) else v) for k,v in row.items()})
                    return self.send_bytes(output.getvalue().encode(),'text/csv; charset=utf-8')
                if path in ('/api/frame.jpg','/api/preview.jpg'):
                    name=approach_name(q.get('approach',['Front'])[0])
                    if path=='/api/frame.jpg' and not app.cameras[name]['frame_ready']: return self.json({'error':'No frame'},404)
                    file=app.runtime/('frames' if path=='/api/frame.jpg' else 'previews')/(name+'.jpg')
                    return self.send_bytes(file.read_bytes(),'image/jpeg') if file.is_file() else self.json({'error':'No frame'},404)
                if path.startswith('/evidence/'):
                    name=path.removeprefix('/evidence/')
                    if Path(name).name!=name or not name.endswith('.jpg'): raise ValueError('Invalid evidence path')
                    file=app.runtime/'evidence'/name
                    return self.send_bytes(file.read_bytes(),'image/jpeg') if file.is_file() else self.json({'error':'Not found'},404)
                return super().do_GET()
            except (ValueError,KeyError) as exc: return self.json({'error':str(exc)},400)
        def do_POST(self):
            if self.headers.get('Origin') and self.headers['Origin']!='http://'+self.headers.get('Host',''): return self.json({'error':'Origin rejected'},403)
            parsed=urlparse(self.path);path=parsed.path;q=parse_qs(parsed.query)
            try:
                segments=path.strip('/').split('/')
                if len(segments)==4 and segments[:2]==['api','cameras']:
                    road=app.dashboard.road(segments[2]);name=approach_name(road)
                    if segments[3]=='video':
                        target,label=receive_video(self,app.runtime/'uploads',MAX_UPLOAD)
                        try:
                            result=app.preview(str(target),name,label=label)
                            app.dashboard.invalidate(road)
                            return self.json(result)
                        except Exception: target.unlink(missing_ok=True);raise
                    if segments[3]=='connect':
                        url=self.body().get('url','')
                        if not isinstance(url,str) or not url.removeprefix('usb:').isdigit(): raise ValueError('Use a local USB camera index, e.g. usb:0')
                        index=int(url.removeprefix('usb:'))
                        if not 0<=index<=9: raise ValueError('Camera index must be 0–9')
                        result=app.preview(index,name,label=f'USB camera {index}')
                        app.dashboard.invalidate(road);return self.json(result)
                if path=='/api/control': return self.json(app.dashboard.control(self.body()['action']))
                if path=='/api/upload':
                    name=approach_name(q.get('approach',['Front'])[0]);size=int(self.headers.get('Content-Length',0));ext=self.headers.get('X-File-Extension','').lower()
                    if not 0<size<=MAX_UPLOAD or ext not in ('.mp4','.avi','.mov','.mkv','.webm'): raise ValueError('Choose a supported video up to 500 MB')
                    target=app.runtime/'uploads'/(uuid.uuid4().hex+ext)
                    try:
                        with target.open('wb') as out:
                            left=size
                            while left:
                                chunk=self.rfile.read(min(left,1048576))
                                if not chunk: raise ValueError('Incomplete upload')
                                out.write(chunk);left-=len(chunk)
                        return self.json(app.preview(str(target),name,label=unquote(self.headers.get('X-Source-Name',DISPLAY_NAMES[name]))))
                    except Exception: target.unlink(missing_ok=True);raise
                if path=='/api/camera':
                    data=self.body();index=data.get('index',0)
                    if type(index) is not int or not 0<=index<=9: raise ValueError('Camera index must be 0–9')
                    return self.json(app.preview(index,data['approach'],label=f'USB camera {index}'))
                if path=='/api/preview':
                    data=self.body();name=approach_name(data['approach']);old=app.previews.get(name)
                    if not old: raise ValueError('Upload a video for this approach first')
                    return self.json(app.preview(old['source'],name,float(data.get('seconds',0)),old['source_label']))
                if path=='/api/start':
                    config=self.body()['config']
                    for item in config.get('sources',[]):
                        name=approach_name(item.get('approach'));preview=app.previews.get(name)
                        if not preview or item.get('preview_id')!=preview['preview_id']: raise ValueError(f'{DISPLAY_NAMES[name]}: preview changed; recalibrate it')
                        item.update({k:preview[k] for k in ('source','source_label','width','height','frame_seconds')})
                    app.start_video(config);return self.json(app.snapshot())
                if path=='/api/stop':
                    with app.lifecycle: app.stop_video()
                    return self.json(app.snapshot())
                if path.startswith('/api/action/'):
                    app.action(path.rsplit('/',1)[-1]);return self.json(app.snapshot())
                if path=='/api/priority':
                    data=self.body();vehicle=data.get('vehicle','Ambulance')
                    if vehicle not in ('Ambulance','Police','Fire engine'): raise ValueError('Unsupported priority type')
                    app.request_priority(data.get('approach',data.get('road')),vehicle,'operator request');return self.json(app.dashboard.snapshot() if 'road' in data else app.snapshot())
                if path=='/api/events/review':
                    data=self.body();app.store.review(data['id'],data['status'],data.get('plate'));return self.json({'ok':True})
                if path=='/api/hardware/connect': app.hardware.connect(self.body()['port']);return self.json(app.hardware.snapshot())
                if path=='/api/hardware/disconnect': app.hardware.disconnect();return self.json(app.hardware.snapshot())
                return self.json({'error':'Not found'},404)
            except (ValueError,KeyError,TypeError,ImportError) as exc: return self.json({'error':str(exc)},400)
            except Exception as exc: return self.json({'error':f'{type(exc).__name__}: {exc}'},500)
        def do_PUT(self):
            if self.headers.get('Origin') and self.headers['Origin']!='http://'+self.headers.get('Host',''): return self.json({'error':'Origin rejected'},403)
            try:
                segments=urlparse(self.path).path.strip('/').split('/')
                if len(segments)==4 and segments[:2]==['api','cameras'] and segments[3]=='calibration':
                    data=self.body()
                    if 'counting' in data: return self.json(app.dashboard.calibrate_counting(segments[2],data['counting']))
                    return self.json(app.dashboard.calibrate(segments[2],data['markings'],data.get('signal_roi')))
                return self.json({'error':'Not found'},404)
            except (ValueError,KeyError,TypeError) as exc: return self.json({'error':str(exc)},400)
        def do_PATCH(self):
            if self.headers.get('Origin') and self.headers['Origin']!='http://'+self.headers.get('Host',''): return self.json({'error':'Origin rejected'},403)
            try:
                segments=urlparse(self.path).path.strip('/').split('/')
                if len(segments)==3 and segments[:2]==['api','incidents']:
                    data=self.body();statuses={v:k for k,v in STATUSES.items()}
                    if data.get('status') not in statuses: raise ValueError('Invalid review status')
                    app.store.review(int(segments[2]),statuses[data['status']],data.get('plate'))
                    return self.json({'ok':True})
                return self.json({'error':'Not found'},404)
            except (ValueError,KeyError,TypeError) as exc: return self.json({'error':str(exc)},400)
    return Handler


def main():
    parser=argparse.ArgumentParser(description='TrafficSense four-video + Arduino junction')
    parser.add_argument('--port',type=int,default=8765);parser.add_argument('--config');parser.add_argument('--runtime',type=Path)
    args=parser.parse_args();MODELS.mkdir(parents=True,exist_ok=True)
    app=TrafficApp(runtime=args.runtime);stop=threading.Event()
    def loop():
        last=time.monotonic()
        while not stop.wait(.1):
            now=time.monotonic();app.tick(min(now-last,1));last=now
    threading.Thread(target=loop,daemon=True).start()
    if args.config: app.start_video(json.loads(Path(args.config).read_text()))
    server=ThreadingHTTPServer(('127.0.0.1',args.port),make_handler(app));print(f'TrafficSense: http://127.0.0.1:{args.port}',flush=True)
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: stop.set();app.running=False;app.worker_stop.set();app.hardware.disconnect();server.server_close()

if __name__=='__main__': main()
