"""Validate locally labelled YOLO datasets before training; no model imports needed."""
import hashlib
import math
from pathlib import Path

CLASSES = {
    'emergency': ['ambulance', 'police car', 'fire truck', 'car', 'truck', 'bus', 'motorcycle'],
    'helmet': ['motorcycle helmet', 'bare human head'],
    'plate': ['license plate'],
}


def inspect_dataset(root, task):
    root = Path(root).resolve()
    names = CLASSES[task]
    summary = {'root': str(root), 'task': task, 'names': names, 'splits': {}}
    hashes = {}
    for split in ('train', 'val', 'test'):
        folder = root / 'images' / split
        images = sorted(p for p in folder.rglob('*') if p.suffix.lower() in {'.jpg', '.jpeg', '.png'})
        if not images:
            raise ValueError(f'{split}: add labelled images under {folder}')
        counts = [0] * len(names)
        negatives = 0
        for image in images:
            digest = hashlib.sha256(image.read_bytes()).hexdigest()
            if digest in hashes and hashes[digest] != split:
                raise ValueError(f'Data leakage: identical image in {hashes[digest]} and {split}: {image}')
            hashes[digest] = split
            label = (root / 'labels' / split / image.relative_to(folder)).with_suffix('.txt')
            if not label.is_file():
                raise ValueError(f'Missing annotation: {label}; use an empty file for a reviewed negative')
            rows = label.read_text().splitlines()
            nonempty = [row for row in rows if row.strip()]
            negatives += not nonempty
            for row in nonempty:
                try:
                    values = [float(v) for v in row.split()]
                    if len(values) != 5 or not all(math.isfinite(v) for v in values):
                        raise ValueError()
                    cls, x, y, w, h = values
                    if cls != int(cls) or not 0 <= cls < len(names):
                        raise ValueError()
                    if not (0 <= x <= 1 and 0 <= y <= 1 and 0 < w <= 1 and 0 < h <= 1):
                        raise ValueError()
                    if x-w/2 < -1e-6 or y-h/2 < -1e-6 or x+w/2 > 1+1e-6 or y+h/2 > 1+1e-6:
                        raise ValueError()
                except ValueError as exc:
                    raise ValueError(f'Invalid YOLO box in {label}: {row}') from exc
                counts[int(cls)] += 1
        if any(n == 0 for n in counts):
            raise ValueError(f'{split}: every class needs examples; counts={counts}')
        summary['splits'][split] = {'images': len(images), 'negative_images': negatives, 'class_boxes': counts}
    return summary
