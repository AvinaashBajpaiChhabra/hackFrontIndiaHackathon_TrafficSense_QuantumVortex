"""USB serial bridge for a tabletop Arduino LED junction only."""
import threading
import time


def encode_signals(signals):
    codes={'red':'R','yellow':'Y','green':'G'}
    values=[codes[signals[n]] for n in ('North','East','South','West')]
    if sum(v!='R' for v in values)>1:
        raise ValueError('Conflicting signal command')
    return ''.join(values)


def serial_ports():
    try:
        from serial.tools import list_ports
        return [{'port':p.device,'description':p.description} for p in list_ports.comports() if p.vid is not None or any(word in p.device.lower() for word in ('usbmodem','usbserial','ttyacm','ttyusb'))]
    except ImportError:
        return []

class ArduinoBridge:
    def __init__(self, provider):
        self.provider=provider
        self.lock=threading.RLock()
        self.stop=threading.Event()
        self.thread=None
        self.status={'connected':False,'port':None,'message':'Not connected','acknowledged':None}

    def snapshot(self):
        with self.lock:
            return dict(self.status)

    def connect(self, port):
        if port not in [p['port'] for p in serial_ports()]:
            raise ValueError('Select an available USB serial port')
        if self.thread and self.thread.is_alive():
            raise ValueError('Disconnect the current board first')
        self.stop.clear()
        self.thread=threading.Thread(target=self._run,args=(port,),daemon=True)
        self.thread.start()

    def disconnect(self):
        self.stop.set()
        if self.thread:
            self.thread.join(timeout=2)

    def _run(self, port):
        connection=None
        try:
            import serial
            with self.lock:
                self.status.update(port=port,message='Waiting for board reset…',connected=False,acknowledged=None)
            connection=serial.Serial(port,115200,timeout=.15,write_timeout=.5)
            if self.stop.wait(2.2):
                return
            connection.reset_input_buffer()
            seq=0
            while not self.stop.is_set():
                signals=self.provider()
                values=encode_signals(signals) if signals is not None else None
                seq+=1
                command=f"SET {seq} {values}\n" if values else f"STOP {seq}\n"
                connection.write(command.encode())
                deadline=time.monotonic()+.7
                response=None
                accepted=False
                while time.monotonic()<deadline and not self.stop.is_set():
                    line=connection.readline().decode(errors='replace').strip().split()
                    if len(line)==3 and line[0] in ('ACK','NACK') and line[1]==str(seq) and len(line[2])==4 and all(c in 'RYG' for c in line[2]):
                        response=line[2]
                        accepted=line[0]=='ACK'
                        break
                with self.lock:
                    self.status.update(connected=response is not None,acknowledged=response,
                        message=('Board acknowledged '+response if accepted else 'Board held '+response+' · interlock/clearance') if response else 'No acknowledgement · board watchdog will set all-red')
                self.stop.wait(.25)
        except Exception as exc:
            with self.lock:
                self.status.update(connected=False,message=f'{type(exc).__name__}: {exc}',acknowledged=None)
        finally:
            if connection:
                try:
                    connection.write(b'STOP 0\n')
                except Exception:
                    pass
                connection.close()
            with self.lock:
                self.status['connected']=False
                self.status['acknowledged']=None
                if self.stop.is_set():
                    self.status['message']='Disconnected · all-red requested'
