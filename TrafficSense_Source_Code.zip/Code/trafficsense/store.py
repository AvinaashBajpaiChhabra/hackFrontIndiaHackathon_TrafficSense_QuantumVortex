import sqlite3
from pathlib import Path

EXTRA={'violation_type':"TEXT DEFAULT 'red_light'",'place':'TEXT','video_time':'REAL',
    'capture_time':'TEXT','vehicle_image':'TEXT','plate_image':'TEXT','detection_confidence':'REAL',
    'review_status':"TEXT DEFAULT 'needs_review'",'details':'TEXT','session_id':'TEXT'}
FIELDS=('timestamp','approach','track_id','plate','confidence','source','evidence',*EXTRA)

class Store:
    def __init__(self,path):
        self.path=str(path);Path(path).parent.mkdir(parents=True,exist_ok=True)
        with self.connect() as db:
            db.execute('''CREATE TABLE IF NOT EXISTS violations (id INTEGER PRIMARY KEY,
                timestamp TEXT,approach TEXT,track_id TEXT,plate TEXT,confidence REAL,source TEXT,evidence TEXT)''')
            existing={row[1] for row in db.execute('PRAGMA table_info(violations)')}
            for name,definition in EXTRA.items():
                if name not in existing: db.execute(f'ALTER TABLE violations ADD COLUMN {name} {definition}')
            if 'violation_type' not in existing: db.execute("UPDATE violations SET violation_type='synthetic' WHERE source='demo'")
            db.execute('CREATE INDEX IF NOT EXISTS event_source_kind ON violations(source,violation_type,id)')
    def connect(self):
        db=sqlite3.connect(self.path,timeout=10);db.row_factory=sqlite3.Row;return db
    def add(self,event):
        row=dict(event);row.setdefault('review_status','needs_review');row.setdefault('violation_type','red_light')
        with self.connect() as db:
            cursor=db.execute(f'INSERT INTO violations ({",".join(FIELDS)}) VALUES ({",".join("?" for _ in FIELDS)})',[row.get(k) for k in FIELDS])
            return cursor.lastrowid
    def events(self,source=None,limit=200,kind=None,approach=None):
        conditions=[];values=[]
        for column,value in [('source',source),('violation_type',kind),('approach',approach)]:
            if value: conditions.append(column+'=?');values.append(value)
        where=' WHERE '+' AND '.join(conditions) if conditions else ''
        with self.connect() as db:
            return [dict(r) for r in db.execute('SELECT * FROM violations'+where+' ORDER BY id DESC LIMIT ?',(*values,min(int(limit),10000)))]
    def review(self,identity,status,plate):
        if status not in ('needs_review','confirmed','dismissed'): raise ValueError('Invalid review status')
        if plate is not None and (not isinstance(plate,str) or len(plate)>40): raise ValueError('Plate must be at most 40 characters')
        with self.connect() as db:
            result=db.execute('UPDATE violations SET review_status=?,plate=? WHERE id=?',(status,plate or None,int(identity)))
            if result.rowcount!=1: raise ValueError('Event not found')
    def clear_demo(self):
        with self.connect() as db: db.execute("DELETE FROM violations WHERE source='demo'")
