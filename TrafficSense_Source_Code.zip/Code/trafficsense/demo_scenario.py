"""Explicitly injected presentation scenario; never a model detection or hardware command."""
import random

class DemoAmbulance:
    def __init__(self,approach='East',duration=15,rng=None):
        self.approach=approach;self.duration=duration;self.rng=rng or random.Random()
        self.trigger=self.rng.uniform(3,7);self.event=None

    def update(self,approach,video_time,vehicles):
        if approach!=self.approach:return None
        if self.event is None and video_time>=self.trigger and vehicles:
            identity,*_=self.rng.choice(vehicles)
            self.event={'approach':approach,'track_id':identity,'started':video_time,
                'ends':video_time+self.duration,'duration':self.duration,'simulated':True,
                'vehicle':'Simulated ambulance','source':'Injected demo scenario'}
        return self.event if self.event and video_time<self.event['ends'] else None
