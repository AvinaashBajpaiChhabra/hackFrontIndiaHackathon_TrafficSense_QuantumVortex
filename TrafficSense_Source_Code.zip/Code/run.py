"""Launch with the installed project interpreter (including from system Python)."""
import os
import sys
from pathlib import Path

def main():
    root=Path(__file__).resolve().parent
    executable=root/'.venv'/('Scripts/python.exe' if os.name=='nt' else 'bin/python')
    if not executable.is_file():
        raise SystemExit('Install the project environment first; see README.md.')
    os.chdir(root)
    os.execv(str(executable),[str(executable),'-m','trafficsense.server',*sys.argv[1:]])

if __name__=='__main__': main()
