"""Download official vehicle/OCR weights; never invent emergency model capabilities."""
import os
import certifi
os.environ.setdefault('SSL_CERT_FILE', certifi.where())
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
os.environ['YOLO_CONFIG_DIR']=str(ROOT/'runtime/ultralytics')
os.environ['MPLCONFIGDIR']=str(ROOT/'runtime/matplotlib')
models=ROOT/'runtime/models';models.mkdir(parents=True,exist_ok=True)
os.chdir(models)
from ultralytics import YOLO
YOLO('yolo11n.pt')
import easyocr
easyocr.Reader(['en'],gpu=False,model_storage_directory=str(ROOT/'runtime/easyocr'),verbose=False)
print('Vehicle and English OCR models ready. Add a separately trained emergency detector to runtime/models for automatic priority recognition.')
