"""Exercise the supplied HTML's API contract with three real-model test feeds."""
import argparse
import hashlib
import json
import time
from pathlib import Path
import requests

ROOT=Path(__file__).resolve().parents[1]
MARKS={'stop':[{'x':0,'y':.99},{'x':1,'y':.99}],
       'traffic':[{'x':0,'y':0},{'x':1,'y':0}],
       'pedestrian':[{'x':0,'y':.995},{'x':1,'y':.995},{'x':1,'y':1},{'x':0,'y':1}]}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port',type=int,default=8773)
    args=parser.parse_args();base=f'http://127.0.0.1:{args.port}'
    def request(method,path,**kwargs):
        r=requests.request(method,base+path,timeout=30,**kwargs);r.raise_for_status();return r.json()
    served=requests.get(base+'/',timeout=10);served.raise_for_status()
    assert served.content==(ROOT/'trafficsense/static/TrafficSense.html').read_bytes()
    geometry=request('GET','/api/calibration/geometry');assert [g['key'] for g in geometry]==['stop','traffic','pedestrian']
    fixture=ROOT/'runtime/four-input-fixture.mp4'
    if not fixture.exists(): raise SystemExit('Run scripts/verify_four_inputs.py once to create the repeated-photo fixture.')
    request('POST','/api/control',json={'action':'stop'})
    for road in ('Front','Right'):
        with fixture.open('rb') as video:
            request('POST',f'/api/cameras/{road.lower()}/video',files={'video':('TEST-repeated-photo.mp4',video,'video/mp4')})
        request('PUT',f'/api/cameras/{road.lower()}/calibration',json={'markings':MARKS})
    snapshot=request('GET','/api/snapshot');assert len(snapshot['calibrations'])==2
    request('POST','/api/control',json={'action':'start'})
    deadline=time.monotonic()+180;ready=False;paused=False;resumed=False;priority=False;last=None
    while time.monotonic()<deadline:
        s=request('GET','/api/snapshot');raw=request('GET','/api/state');last=s
        if raw['error']:raise AssertionError(raw['error'])
        if raw['control_ready']:
            ready=True
            assert raw['effective_signals']['West']=='red'
            assert all(raw['counts'][n]>0 for n in ('North','East'))
            if not paused:
                p=request('POST','/api/control',json={'action':'pause'});assert p['analysisState']=='Paused'
                assert request('GET','/api/state')['effective_signals']==dict.fromkeys(('North','East','South','West'),'red')
                paused=True
                request('POST','/api/control',json={'action':'start'});resumed=True
            elif not priority:
                request('POST','/api/priority',json={'road':'Right','source':'manual'});priority=True
        if raw['pipeline_state'] in ('finished','error'):break
        time.sleep(.25)
    assert ready and paused and resumed and priority
    assert last['analysisState']=='Finished',last['analysisState']
    assert request('GET','/api/state')['effective_signals']==dict.fromkeys(('North','East','South','West'),'red')
    report={'fixture':'Two independent repeated-photo test clips, not real intersection footage',
        'served_html_sha256':hashlib.sha256(served.content).hexdigest(),'multipart_uploads':2,
        'independent_calibrations':2,'real_model_two_feed_processing':True,
        'pause_all_red_and_resume':True,'manual_priority_contract':True,'disabled_west_always_red':True,
        'eof_all_red':True,'physical_arduino':'not connected',
        'ui_limit':'The unchanged HTML exposes only Front calibration; Right calibration was submitted through the API.'}
    (ROOT/'runtime/user-dashboard-check.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))

if __name__=='__main__':main()
