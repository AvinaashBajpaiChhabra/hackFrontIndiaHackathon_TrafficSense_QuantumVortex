"""HTTP + real-model check. Repeated-photo clips are software fixtures, not real traffic footage."""
import argparse
import json
import time
import urllib.error
import urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
parser=argparse.ArgumentParser();parser.add_argument('--port',type=int,default=8767);args=parser.parse_args()
BASE=f'http://127.0.0.1:{args.port}'
import cv2

def get(path): return urllib.request.urlopen(BASE+path,timeout=30)
def post(path,data=None,raw=None,headers=None):
    req=urllib.request.Request(BASE+path,data=raw if raw is not None else json.dumps(data or {}).encode(),method='POST',headers=headers or {'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=60) as response: return json.load(response)

fixture=ROOT/'runtime/four-input-fixture.mp4'
photo=cv2.imread(str(ROOT/'tests/fixtures/traffic-reference.jpg'))
if photo is None: raise SystemExit('Provide tests/fixtures/traffic-reference.jpg for the optional real-model smoke check.')
h,w=photo.shape[:2];writer=cv2.VideoWriter(str(fixture),cv2.VideoWriter_fourcc(*'mp4v'),5,(w,h));assert writer.isOpened()
for _ in range(60): writer.write(photo)
writer.release()
setup=json.load(get('/api/setup'));assert 'helmet-world.pt' in setup['models'];assert get('/').status==200
sources=[]
for name in ('North','East','South','West'):
    preview=post('/api/upload?approach='+name,raw=fixture.read_bytes(),headers={'X-File-Extension':'.mp4','X-Source-Name':'TEST-repeated-traffic-photo-'+name})
    if name=='North': preview=post('/api/preview',{'approach':name,'seconds':1})
    sources.append({'approach':name,'preview_id':preview['preview_id'],'roi':[0,0,1,1],'stop_line':[[0,.99],[1,.99]],'direction':1,'offset':0})
try:
    post('/api/start',{'config':{'sources':sources[:3]}})
    raise AssertionError('Three inputs unexpectedly accepted')
except urllib.error.HTTPError as exc: assert exc.code==400
post('/api/start',{'config':{'sources':sources,'junction':'SMOKE TEST: repeated traffic photo, not real intersection footage',
    'vehicle_model':'yolo11n.pt','emergency_model':'emergency-world.pt','helmet_model':'helmet-world.pt','ocr':True,'analysis_fps':5,'stale_seconds':5}})
deadline=time.monotonic()+180;seen_ready=False;requested=False;stages=set();counts={}
while time.monotonic()<deadline:
    state=json.load(get('/api/state'));assert state['error'] is None,state['error']
    assert not any(c['error'] for c in state['cameras'].values()),state['cameras']
    if state['control_ready']:
        seen_ready=True;counts=state['counts'];assert all(v>0 for v in counts.values()),counts
        assert list(state['effective_signals'].values()).count('green')<=1
        if not requested:
            target='East' if state['controller']['active']!='East' else 'West'
            post('/api/priority',{'approach':target,'vehicle':'Ambulance'});requested=True
        else: stages.add(state['controller']['stage'])
    if state['pipeline_state'] in ('finished','error'): break
    time.sleep(.25)
assert state['pipeline_state']=='finished',state['pipeline_state'];assert seen_ready,'Four-camera controller never became ready'
assert state['capabilities']['helmet'] and state['capabilities']['emergency'] and state['capabilities']['plate']
assert state['effective_signals']==dict.fromkeys(('North','East','South','West'),'red')
for name in ('North','East','South','West'): assert get('/api/frame.jpg?approach='+name).read().startswith(b'\xff\xd8')
csv=get('/api/events.csv').read();assert b'violation_type' in csv and b'video_time' in csv
report={'fixture':'four independent copies of a repeated traffic photo; NOT four real intersection videos',
    'four_uploads_and_frame_seek':'passed','reject_incomplete_session':'passed','all_four_became_fresh':seen_ready,
    'actual_model_counts_on_fixture':counts,'capabilities':state['capabilities'],'operator_priority_stages_observed':sorted(stages),
    'eof_forces_all_red':True,'four_annotated_jpegs':'passed','typed_csv':'passed','physical_arduino':'not connected','real_helmet_accuracy':'not evaluated'}
(ROOT/'docs/four-input-smoke-results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2),flush=True)
