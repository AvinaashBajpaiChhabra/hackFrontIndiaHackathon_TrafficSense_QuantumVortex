"""Prepare experimental emergency or helmet/head prompts from official YOLO-World weights."""
import os
import argparse
parser=argparse.ArgumentParser()
parser.add_argument("--helmet",action="store_true")
args=parser.parse_args()
import signal
if hasattr(signal,'SIGALRM'):
    def timed_out(*_):
        raise TimeoutError('Model preparation exceeded 120 seconds. Retry to resume the partial download.')
    signal.signal(signal.SIGALRM,timed_out)
    signal.alarm(120)
import certifi
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
os.environ.setdefault('SSL_CERT_FILE',certifi.where())
os.environ['YOLO_CONFIG_DIR']=str(ROOT/'runtime/ultralytics')
os.environ['MPLCONFIGDIR']=str(ROOT/'runtime/matplotlib')
models=ROOT/'runtime/models';models.mkdir(parents=True,exist_ok=True)
os.chdir(models)
from ultralytics import YOLOWorld
from ultralytics.utils import SETTINGS
SETTINGS.update({'weights_dir':str(models)})
model=YOLOWorld('yolov8s-worldv2.pt')
# Fetch the official CLIP file with bounded timeouts and resumable requests.
# The upstream helper has an unbounded socket read on some networks.
import hashlib
import requests
from clip.clip import _MODELS
from ultralytics.nn import text_model
url=_MODELS['ViT-B/32']
target=Path(text_model.WEIGHTS_DIR)/'clip/ViT-B-32.pt'
target.parent.mkdir(parents=True,exist_ok=True)
expected=url.split('/')[-2]
for attempt in range(4):
    if target.exists() and hashlib.sha256(target.read_bytes()).hexdigest()==expected:
        break
    offset=target.stat().st_size if target.exists() else 0
    try:
        with requests.get(url+'?resume='+str(offset),headers={'Range':f'bytes={offset}-'},stream=True,timeout=(15,20)) as response:
            response.raise_for_status()
            print('CLIP download:',response.status_code,response.headers.get('Content-Range'),flush=True)
            append=response.status_code==206 and response.headers.get('Content-Range','').startswith(f'bytes {offset}-')
            if response.status_code==206 and not append:
                raise RuntimeError('Unexpected range response')
            with target.open('ab' if append else 'wb') as output:
                for chunk in response.iter_content(64*1024):
                    if chunk: output.write(chunk)
    except requests.RequestException as exc:
        print(f'CLIP download attempt {attempt+1}: {type(exc).__name__}; will resume',flush=True)
if not target.exists() or hashlib.sha256(target.read_bytes()).hexdigest()!=expected:
    raise RuntimeError('Official CLIP checksum not complete; retry preparation to resume')
if args.helmet:
    model.set_classes(['motorcycle helmet','bare human head','person','motorcycle'])
    model.save(str(models/'helmet-world.pt'))
    print('Saved helmet-world.pt: experimental head/helmet prompts. Explicit rider association and manual review are required.')
else:
    model.set_classes(['ambulance','police car','fire truck','car','truck','bus','motorcycle'])
    model.save(str(models/'emergency-world.pt'))
    print('Saved emergency-world.pt: experimental zero-shot prompts, not a validated emergency classifier.')
