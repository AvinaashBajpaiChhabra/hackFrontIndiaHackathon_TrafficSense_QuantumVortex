"""Create a local environment even when the checkout path contains a colon.
Use explicit .venv/bin/python -m commands; shell activation cannot encode that PATH.
"""
import os
import sys
import tempfile
import venv
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
if not (3,10)<=sys.version_info[:2]<(3,14):
    raise SystemExit('Run this helper with Python 3.10–3.13; Python 3.11 is recommended.')
if (ROOT/'.venv').exists():
    raise SystemExit('An environment already exists; it was left unchanged.')
with tempfile.TemporaryDirectory(prefix='trafficsense-setup-') as tmp:
    alias=Path(tmp)/'project'
    alias.symlink_to(ROOT,target_is_directory=True)
    venv.EnvBuilder(with_pip=True).create(str(alias/'.venv'))
print('Environment created. Use .venv/bin/python -m pip install -r requirements-vision.txt')
