"""Validate, fine-tune and evaluate a custom detector on a held-out test split."""
import argparse
import json
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from trafficsense.training import inspect_dataset


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--task', choices=['emergency', 'helmet', 'plate'], required=True)
    parser.add_argument('--dataset', type=Path, required=True)
    parser.add_argument('--check-only', action='store_true')
    parser.add_argument('--weights', type=Path, default=ROOT/'runtime/models/yolo11n.pt')
    parser.add_argument('--epochs', type=int, default=50)
    parser.add_argument('--device', default='cpu', help='cpu, mps, or CUDA device index')
    parser.add_argument('--batch', type=int, default=8)
    parser.add_argument('--name', default=None)
    args = parser.parse_args()
    if args.epochs < 1 or args.batch < 1:
        parser.error('epochs and batch must be positive')
    try:
        report = inspect_dataset(args.dataset, args.task)
    except (ValueError, OSError) as exc:
        parser.error(str(exc))
    print(json.dumps(report, indent=2))
    if args.check_only:
        return
    if not args.weights.is_file():
        parser.error('Local pretrained checkpoint missing; run scripts/download_models.py first')
    from ultralytics import YOLO
    import yaml
    output = ROOT/'runtime/training'
    output.mkdir(parents=True, exist_ok=True)
    config = output/f'{args.task}-dataset.yaml'
    config.write_text(yaml.safe_dump({'path': report['root'], 'train': 'images/train',
        'val': 'images/val', 'test': 'images/test', 'names': report['names']}))
    model = YOLO(str(args.weights.resolve()))
    model.train(data=str(config), epochs=args.epochs, imgsz=640, batch=args.batch,
        device=args.device, project=str(output), name=args.name or args.task,
        seed=42, workers=0, exist_ok=False)
    best = Path(model.trainer.best)
    metrics = YOLO(str(best)).val(data=str(config), split='test', device=args.device,
        project=str(output), name=f'{best.parent.parent.name}-held-out', exist_ok=False)
    report.update(checkpoint=str(best), test_metrics={k: float(v) for k,v in metrics.results_dict.items()},
        limitations='Held-out image metrics only; temporal incident and road-level accuracy need separate evaluation.')
    destination = best.parent.parent/'evaluation.json'
    destination.write_text(json.dumps(report, indent=2))
    print(f'Checkpoint: {best}\nEvaluation: {destination}\nNot automatically deployed; review results before selecting this checkpoint.')


if __name__ == '__main__':
    main()
