# Packaged copy

For the final folder layout and the selected videos, read ../START_HERE.md. The original project README and docs are included as technical references and can mention paths specific to the working project. In this copy, use ../Demo Video/ for the selected inputs. The source workspace remains unchanged. Model files are included; the Python environment must be installed separately.
