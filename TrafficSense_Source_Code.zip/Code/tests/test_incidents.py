import json
import sqlite3
import tempfile
import time
import unittest
from pathlib import Path
from trafficsense.incidents import ObstructionDetector,Confirmation,helmet_status,inside
from trafficsense.session import validate_session
from trafficsense.store import Store
from trafficsense.server import TrafficApp
from trafficsense.core import APPROACHES,Controller,Timing

POLYGON=[[0,0],[1,0],[1,1],[0,1]]
def configuration():
    return {'sources':[{'approach':name,'source':f'{name}.mp4','roi':[0,0,1,1],
        'stop_line':[[0,.7],[1,.7]],'direction':1,'crosswalk':POLYGON} for name in ('Front','Right','Back','Left')]}

class IncidentTests(unittest.TestCase):
    def test_stationary_crossing_obstruction_deduplicates(self):
        d=ObstructionDetector(POLYGON,seconds=3)
        for t in range(3): self.assertFalse(d.update(1,(.5,.5),t))
        self.assertTrue(d.update(1,(.5,.5),3));self.assertFalse(d.update(1,(.5,.5),4))
        d.update(1,(2,2),5);self.assertFalse(d.update(1,(.5,.5),6))
        d.update(1,(.5,.5),7);d.update(1,(.5,.5),8);self.assertTrue(d.update(1,(.5,.5),9))
    def test_moving_or_missing_vehicle_is_not_obstruction(self):
        d=ObstructionDetector(POLYGON,seconds=3)
        for t in range(10): self.assertFalse(d.update(1,(t/12,.5),t))
        d=ObstructionDetector(POLYGON,seconds=3)
        self.assertFalse(d.update(1,(.5,.5),0));self.assertFalse(d.update(1,(.5,.5),10))
    def test_polygon_outside_and_boundary(self):
        self.assertTrue(inside((0,.5),POLYGON));self.assertFalse(inside((2,.5),POLYGON))
    def test_helmet_absence_is_uncertain_and_conflicts_not_reported(self):
        p=[(2,[120,10,220,220])];b=[(1,[100,150,250,270])];head=[150,20,190,60]
        self.assertEqual(helmet_status(2,1,p,b,[])[0],'uncertain')
        self.assertEqual(helmet_status(2,1,p,b,[('bare_head',.9,head)])[0],'no_helmet')
        self.assertEqual(helmet_status(2,1,p,b,[('bare_head',.9,head),('helmet',.5,head)])[0],'uncertain')
        self.assertEqual(helmet_status(2,1,p,b,[('helmet',.9,head)])[0],'helmet')
        self.assertEqual(helmet_status(2,1,p,b,[('bare_head',.3,head)])[0],'uncertain')
        self.assertEqual(helmet_status(2,1,p,b+[ (3,[130,150,280,270]) ],[('bare_head',.9,head)])[0],'uncertain')
    def test_positive_helmet_evidence_requires_repeated_frames(self):
        d=Confirmation(3)
        self.assertFalse(d.update((2,1),True,0));self.assertFalse(d.update((2,1),True,.2))
        self.assertFalse(d.update((2,1),False,.4));self.assertFalse(d.update((2,1),True,.6))
        self.assertFalse(d.update((2,1),True,.8));self.assertTrue(d.update((2,1),True,1))
        self.assertFalse(d.update((2,1),True,1.2))
    def test_session_requires_four_unique_roads_and_allows_overlapping_camera_coordinates(self):
        c=validate_session(configuration());self.assertEqual([s['approach'] for s in c['sources']],list(APPROACHES))
        c=configuration();c['sources'].pop()
        with self.assertRaises(ValueError): validate_session(c)
        c=configuration();c['sources'][1]['approach']='Front'
        with self.assertRaises(ValueError): validate_session(c)
        c=configuration();c['sources'][0]['offset']=float('nan')
        with self.assertRaises(ValueError): validate_session(c)
        c=configuration();c['sources'][0]['capture_start']='2026-10-27T10:00:00'
        with self.assertRaises(ValueError): validate_session(c)
    def test_old_database_migration_and_review(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'old.db'
            with sqlite3.connect(path) as db:
                db.execute('CREATE TABLE violations (id INTEGER PRIMARY KEY,timestamp TEXT,approach TEXT,track_id TEXT,plate TEXT,confidence REAL,source TEXT,evidence TEXT)')
                db.execute("INSERT INTO violations(source,plate) VALUES ('video','OLD123')")
            store=Store(path);row=store.events()[0]
            self.assertEqual(row['plate'],'OLD123');self.assertEqual(row['violation_type'],'red_light')
            store.review(row['id'],'dismissed','NEW123');self.assertEqual(store.events()[0]['review_status'],'dismissed')
    def test_camera_staleness_pause_and_eof_hold_hardware_all_red(self):
        with tempfile.TemporaryDirectory() as tmp:
            app=TrafficApp(runtime=tmp);app.mode='video';app.running=True;app.pipeline_state='processing';app.config=validate_session(configuration())
            for c in app.cameras.values(): c.update(status='processing',count=1,last_frame=time.monotonic())
            self.assertTrue(app.healthy());self.assertIsNotNone(app.hardware_signals())
            app.error='Evidence write failed';self.assertIsNone(app.hardware_signals());app.error=None
            app.cameras['North']['last_frame']-=10
            self.assertIsNone(app.hardware_signals())
            app.cameras['North']['last_frame']=time.monotonic();app.running=False;self.assertIsNone(app.hardware_signals())
            app.running=True;app.cameras['East']['status']='finished';self.assertIsNone(app.hardware_signals())
    def test_emergencies_queue_without_overwriting_active_priority(self):
        with tempfile.TemporaryDirectory() as tmp:
            app=TrafficApp(runtime=tmp);app.mode='video';app.running=True;app.pipeline_state='processing';app.config=validate_session(configuration())
            for c in app.cameras.values(): c.update(status='processing',count=1,last_frame=time.monotonic())
            app.request_priority('Front','Ambulance','AI test');app.request_priority('Right','Fire engine','AI test')
            self.assertEqual(app.controller.active,0);self.assertEqual(app.controller.priority,0)
            self.assertEqual(len(app.priority_queue),1)
            app.tick(20.1);self.assertEqual(app.controller.priority,1);self.assertEqual(len(app.priority_queue),0)
    def test_pedestrian_clearance_blocks_new_green(self):
        c=Controller(Timing(min_green=1,max_green=1,yellow=1,all_red=1))
        c.pedestrian_blocked=True;c.advance(5,[1]*4)
        self.assertEqual(c.stage,'all_red');self.assertEqual(set(c.snapshot()['signals'].values()),{'red'})
        c.pedestrian_blocked=False;c.advance(.1,[1]*4);self.assertEqual(c.stage,'green')
        c.request_pedestrian(5);c.advance(3,[1]*4);self.assertTrue(c.snapshot()['pedestrian']['walk'])
        c.advance(5.1,[1]*4);self.assertFalse(c.snapshot()['pedestrian']['walk'])

if __name__=='__main__': unittest.main()
