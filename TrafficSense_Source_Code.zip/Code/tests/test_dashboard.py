import io
import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from trafficsense.dashboard import markings_source,receive_video
from trafficsense.core import Controller
from trafficsense.server import TrafficApp

MARKS={'stop':[{'x':.1,'y':.65},{'x':.9,'y':.65}],
       'traffic':[{'x':.1,'y':.1},{'x':.9,'y':.1}],
       'pedestrian':[{'x':.1,'y':.7},{'x':.9,'y':.7},{'x':.9,'y':.8},{'x':.1,'y':.8}]}

class DashboardTests(unittest.TestCase):
    def test_geometry_derives_upstream_counting_region_and_direction(self):
        result=markings_source(MARKS)
        self.assertEqual(result['roi'],[.1,.1,.9,.65])
        self.assertEqual(result['direction'],1)
        self.assertIsNone(result['signal_roi'])
        bad=json.loads(json.dumps(MARKS));bad['traffic']=bad['stop']
        with self.assertRaises(ValueError):markings_source(bad)
        for value in [True,float('nan'),-1,2]:
            bad=json.loads(json.dumps(MARKS));bad['stop'][0]['x']=value
            with self.assertRaises(ValueError):markings_source(bad)

    def test_three_road_controller_never_serves_disabled_lane(self):
        c=Controller(enabled=['North','East','South']);seen=set()
        for _ in range(1400):
            c.advance(.1,[12,9,7,100]);s=c.snapshot()
            self.assertEqual(s['signals']['West'],'red')
            if s['stage']=='green':seen.add(s['active'])
        self.assertEqual(seen,{'North','East','South'})
        with self.assertRaises(ValueError):c.request_priority('West')

    def test_snapshot_preserves_unknown_hardware_and_review_evidence(self):
        with tempfile.TemporaryDirectory() as tmp:
            app=TrafficApp(runtime=tmp)
            app.store.add({'source':'video','approach':'East','violation_type':'red_light','video_time':3,
                'evidence':'/evidence/test.jpg','plate':None})
            s=app.dashboard.snapshot()
            self.assertIsNone(s['recommendation']);self.assertIsNone(s['cameras'][0]['count'])
            self.assertEqual(s['hardware']['signals']['Front'],'unknown')
            self.assertEqual(s['incidents'][0]['id'],'1')
            self.assertEqual(s['incidents'][0]['road'],'Right')
            self.assertEqual(s['incidents'][0]['image'],'/evidence/test.jpg')
            app.hardware.status.update(connected=True,acknowledged='GRRR')
            self.assertEqual(app.dashboard.snapshot()['hardware']['signals']['Front'],'green')
            app.hardware.status.update(acknowledged='GGRR')
            self.assertFalse(app.dashboard.snapshot()['hardware']['connected'])

    def test_calibration_persistence_and_source_replacement(self):
        with tempfile.TemporaryDirectory() as tmp:
            app=TrafficApp(runtime=tmp);source=Path(tmp)/'uploads/a.mp4';source.write_bytes(b'fixture')
            for road,name in [('Front','North'),('Right','East')]:
                (Path(tmp)/'previews'/f'{name}.jpg').write_bytes(b'fixture')
                app.previews[name]={'source':str(source),'preview_id':name,'url':'/api/preview.jpg?approach='+name,'width':100,'height':100,'source_label':road,'frame_seconds':0}
                app.dashboard.calibrate(road,MARKS,signal_roi=[.1,.1,.2,.2] if road=='Front' else None)
            config=app.dashboard.configuration()
            self.assertFalse(config['require_four']);self.assertEqual(len(config['sources']),2)
            self.assertEqual(config['sources'][0]['signal_roi'],[.1,.1,.2,.2])
            app2=TrafficApp(runtime=tmp)
            self.assertEqual(len(app2.dashboard.snapshot()['calibrations']),2)
            app2.previews['East']['preview_id']='replacement'
            self.assertTrue(app2.dashboard.configuration()['analysis_only'])
            app2.dashboard.invalidate('Right')
            self.assertNotIn('Right',app2.dashboard.snapshot()['calibrations'])

    def test_three_required_inputs_stale_fallback(self):
        import time
        with tempfile.TemporaryDirectory() as tmp:
            app=TrafficApp(runtime=tmp)
            app.config={'sources':[{'approach':n} for n in ['North','East','South']]}
            app.pipeline_state='processing';app.running=True
            for n in ['North','East','South']:app.cameras[n].update(status='processing',last_frame=time.monotonic(),count=2)
            self.assertTrue(app.healthy())
            app.cameras['East']['last_frame']=0
            self.assertIsNone(app.hardware_signals())

class MultipartTests(unittest.TestCase):
    def handler(self,payload):
        return SimpleNamespace(headers={'Content-Type':'multipart/form-data; boundary=BOUNDARY','Content-Length':str(len(payload))},rfile=io.BytesIO(payload))
    def body(self,data=b'video-data'):
        return b'--BOUNDARY\r\nContent-Disposition: form-data; name="video"; filename="input.mp4"\r\nContent-Type: video/mp4\r\n\r\n'+data+b'\r\n--BOUNDARY--\r\n'
    def test_stream_upload_and_limits(self):
        with tempfile.TemporaryDirectory() as tmp:
            data=b'x'*(1024*1024+7)
            path,name=receive_video(self.handler(self.body(data)),tmp,len(data))
            self.assertEqual(path.read_bytes(),data);self.assertEqual(name,'input.mp4')
            with self.assertRaises(ValueError):receive_video(self.handler(self.body()),tmp,3)
    def test_missing_final_boundary_rejected_and_partial_removed(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(ValueError):receive_video(self.handler(self.body()[:-20]),tmp,1000)
            self.assertEqual(list(Path(tmp).iterdir()),[])

class HttpContractTests(unittest.TestCase):
    def request(self,app,method,path,data=None,origin=None):
        from trafficsense.server import make_handler
        payload=json.dumps(data).encode() if data is not None else b''
        class Connection:
            output=b''
            def makefile(self,*_): return io.BytesIO(request)
            def sendall(self,value): self.output+=value
        request=f'{method} {path} HTTP/1.0\r\nHost: 127.0.0.1:8765\r\nContent-Type: application/json\r\nContent-Length: {len(payload)}\r\n'.encode()
        if origin:request+=f'Origin: {origin}\r\n'.encode()
        request+=b'\r\n'+payload
        connection=Connection();make_handler(app)(connection,('127.0.0.1',1234),SimpleNamespace())
        headers,body=connection.output.split(b'\r\n\r\n',1)
        status=int(headers.split(b' ')[1]);return status,json.loads(body)

    def test_native_snapshot_review_contract_and_origin_checks(self):
        with tempfile.TemporaryDirectory() as tmp:
            app=TrafficApp(runtime=tmp)
            identity=app.store.add({'source':'video','approach':'North','violation_type':'red_light','video_time':2})
            status,data=self.request(app,'GET','/api/snapshot')
            self.assertEqual(status,200);self.assertEqual(data['incidents'][0]['id'],str(identity))
            status,_=self.request(app,'PATCH',f'/api/incidents/{identity}',{'status':'Confirmed','plate':'TEST123'})
            self.assertEqual(status,200);self.assertEqual(app.store.events()[0]['review_status'],'confirmed')
            status,_=self.request(app,'PATCH',f'/api/incidents/{identity}',{'status':'Dismissed','plate':''},origin='https://outside.example')
            self.assertEqual(status,403);self.assertEqual(app.store.events()[0]['review_status'],'confirmed')
            status,_=self.request(app,'PUT','/api/cameras/right/calibration',{'markings':MARKS})
            self.assertEqual(status,400)
            status,_=self.request(app,'POST','/api/control',{'action':'start'})
            self.assertEqual(status,400)
            status,_=self.request(app,'POST','/api/control',{'action':'emergency-stop'})
            self.assertEqual(status,200);self.assertIsNone(app.hardware_signals())

class PreviewRegressionTests(unittest.TestCase):
    def test_replacing_input_clears_old_annotated_frame_and_counts(self):
        import cv2
        import numpy as np
        with tempfile.TemporaryDirectory() as tmp:
            app=TrafficApp(runtime=tmp);path=Path(tmp)/'uploads/clip.avi'
            writer=cv2.VideoWriter(str(path),cv2.VideoWriter_fourcc(*'MJPG'),5,(32,32))
            self.assertTrue(writer.isOpened());writer.write(np.zeros((32,32,3),dtype=np.uint8));writer.release()
            app.cameras['North'].update(frame_ready=True,count=99,observed='red')
            app.preview(str(path),'Front')
            camera=app.dashboard.snapshot()['cameras'][0]
            self.assertIn('/api/preview.jpg',camera['frame']);self.assertIsNone(camera['count'])
            self.assertEqual(camera['signal'],'unknown')

class SingleVideoCountingTests(unittest.TestCase):
    def test_one_uncalibrated_upload_enables_counting_but_not_hardware(self):
        with tempfile.TemporaryDirectory() as tmp:
            app=TrafficApp(runtime=tmp);video=Path(tmp)/'uploads/test.mp4';video.write_bytes(b'fixture')
            (Path(tmp)/'previews/North.jpg').write_bytes(b'fixture')
            app.previews['North']={'source':str(video),'preview_id':'first','width':100,'height':100,'url':'/api/preview.jpg?approach=North','source_label':'test','frame_seconds':0}
            app.dashboard.invalidate('Front')
            config=app.dashboard.configuration()
            self.assertTrue(config['analysis_only']);self.assertEqual(len(config['sources']),1)
            self.assertTrue(config['sources'][0]['count_only']);self.assertEqual(config['sources'][0]['roi'],[0,0,1,1])
            self.assertFalse(config['ocr']);self.assertIsNone(config['emergency_model'])
            app.config=config;app.running=True;app.pipeline_state='processing'
            self.assertFalse(app.healthy());self.assertIsNone(app.hardware_signals())
            with self.assertRaises(ValueError):app.request_priority('Front')
            restored=TrafficApp(runtime=tmp)
            self.assertTrue(restored.dashboard.configuration()['analysis_only'])
