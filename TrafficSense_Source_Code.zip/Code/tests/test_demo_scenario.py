import random
import tempfile
import time
import unittest
from trafficsense.demo_scenario import DemoAmbulance
from trafficsense.server import TrafficApp

class DemoScenarioTests(unittest.TestCase):
    def test_one_random_vehicle_in_second_video_expiry_and_reset(self):
        demo=DemoAmbulance(rng=random.Random(7));vehicles=[(8,[],1,'car',(0,0)),(9,[],1,'car',(0,0))]
        self.assertIsNone(demo.update('North',10,vehicles))
        self.assertIsNone(demo.update('East',0,vehicles))
        self.assertIsNone(demo.update('East',10,[]))
        event=demo.update('East',10,vehicles)
        self.assertIn(event['track_id'],[8,9]);self.assertTrue(event['simulated'])
        self.assertEqual(demo.update('East',11,vehicles)['track_id'],event['track_id'])
        self.assertIsNone(demo.update('East',26,vehicles))
        self.assertIsNone(demo.update('East',30,vehicles))
        self.assertIsNone(DemoAmbulance().event)

    def test_injected_advisory_never_enables_hardware(self):
        with tempfile.TemporaryDirectory() as tmp:
            app=TrafficApp(runtime=tmp);app.config={'analysis_only':True,'demo_scenario':{'approach':'East'},'sources':[{'approach':'North'},{'approach':'East'}]}
            app.running=True;app.pipeline_state='processing'
            for c in app.cameras.values():c.update(status='processing',count=4,last_frame=time.monotonic())
            app.demo_emergency={'approach':'East','duration':15,'simulated':True,'started':4}
            app.demo_history=[dict(app.demo_emergency)]
            s=app.dashboard.snapshot()
            self.assertEqual(s['recommendation']['road'],'Right');self.assertEqual(s['recommendation']['duration'],15)
            self.assertTrue(s['recommendation']['simulated']);self.assertIn('Simulated',s['emergencies'][0]['type'])
            self.assertFalse(app.healthy());self.assertIsNone(app.hardware_signals())
            app.running=False;self.assertIsNone(app.dashboard.snapshot()['recommendation'])

    def test_normal_demo_alternates_front_and_right(self):
        with tempfile.TemporaryDirectory() as tmp:
            app=TrafficApp(runtime=tmp);app.config={'analysis_only':True,'demo_scenario':{'approach':'East'},'sources':[{'approach':'North'},{'approach':'East'}]}
            app.running=True;app.pipeline_state='processing'
            for n in ['North','East']:app.cameras[n].update(status='processing',count=3,last_frame=time.monotonic(),video_time=2)
            self.assertEqual(app.dashboard.snapshot()['recommendation']['road'],'Front')
            for n in ['North','East']:app.cameras[n]['video_time']=12
            self.assertEqual(app.dashboard.snapshot()['recommendation']['road'],'Right')
            for n in ['North','East']:app.cameras[n]['video_time']=22
            self.assertEqual(app.dashboard.snapshot()['recommendation']['road'],'Front')
            self.assertIsNone(app.hardware_signals())

    def test_completed_demo_remains_in_emergency_list(self):
        with tempfile.TemporaryDirectory() as tmp:
            app=TrafficApp(runtime=tmp)
            app.demo_history=[{'approach':'East','started':4,'simulated':True,'image':'/evidence/demo.jpg'}]
            s=app.dashboard.snapshot()
            self.assertEqual(len(s['emergencies']),1)
            self.assertEqual(s['emergencies'][0]['status'],'Simulated · Priority completed')
            self.assertEqual(s['emergencies'][0]['image'],'/evidence/demo.jpg')
            self.assertIsNone(s['recommendation'])
