import json
import tempfile
import unittest
from pathlib import Path
from trafficsense.models import model_inventory,PRETRAINED
from trafficsense.session import validate_session

class ModelProfileTests(unittest.TestCase):
    def test_default_profile_and_explicit_disable(self):
        config=json.loads(Path('config/session.example.json').read_text())
        for key in PRETRAINED: config.pop(key,None)
        result=validate_session(config)
        self.assertEqual(result['helmet_model'],'helmet-world.pt')
        self.assertEqual(result['emergency_model'],'emergency-world.pt')
        config['helmet_model']=None
        self.assertIsNone(validate_session(config)['helmet_model'])

    def test_inventory_reports_missing_or_empty_files(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            report=model_inventory(root)
            self.assertFalse(report['files_ready'])
            (root/'models').mkdir();(root/'easyocr').mkdir()
            for role in ('vehicle','emergency','helmet'):
                (root/'models'/PRETRAINED[role+'_model']).write_bytes(b'fixture')
            for name in report['components']['ocr']['files']:
                (root/'easyocr'/name).write_bytes(b'fixture')
            self.assertTrue(model_inventory(root)['files_ready'])
            (root/'models'/'helmet-world.pt').write_bytes(b'')
            self.assertFalse(model_inventory(root)['files_ready'])
