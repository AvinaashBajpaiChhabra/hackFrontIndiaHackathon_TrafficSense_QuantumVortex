import json
import tempfile
import unittest
from pathlib import Path
from trafficsense.core import Controller
from trafficsense.vision import EmergencyGate
from trafficsense.session import validate_session
from trafficsense.hardware import encode_signals

class PriorityTests(unittest.TestCase):
    def test_preemption_clears_before_emergency_green(self):
        c=Controller();c.request_priority('East',20,'Ambulance')
        c.advance(.1,[30,1,5,0]);self.assertEqual(c.stage,'yellow');self.assertEqual(c.active,0)
        c.advance(3,[30,1,5,0]);self.assertEqual(c.stage,'all_red')
        self.assertEqual(set(c.snapshot()['signals'].values()),{'red'})
        c.advance(2,[30,1,5,0]);self.assertEqual(c.stage,'green');self.assertEqual(c.active,1)
        self.assertIsNotNone(c.snapshot()['priority'])
    def test_priority_expires_and_cancels(self):
        c=Controller();c.request_priority('North',2)
        c.advance(2.1,[0]*4);self.assertIsNone(c.priority)
        c.request_priority('South');c.cancel_priority();self.assertIsNone(c.priority)
    def test_priority_during_clearance_uses_latest_target(self):
        c=Controller();c.request_priority('East');c.advance(3.5,[0]*4)
        self.assertEqual(c.stage,'all_red')
        c.request_priority('West');c.advance(2,[0]*4)
        self.assertEqual(c.active,3)
    def test_invalid_priority(self):
        c=Controller()
        for approach,seconds in [('nowhere',20),('North',100),('North',0)]:
            with self.assertRaises(ValueError): c.request_priority(approach,seconds)
    def test_emergency_debouncing_and_expiry(self):
        gate=EmergencyGate();item=('East','Ambulance')
        self.assertEqual(gate.update([item],0),[])
        self.assertEqual(gate.update([item],.1),[])
        self.assertEqual(gate.update([item],.2),[item])
        self.assertEqual(gate.update([item],.3),[])
        gate.update([],3)
        for t in [4,4.1]: self.assertEqual(gate.update([item],t),[])
        self.assertEqual(gate.update([item],4.2),[item])
    def test_multi_approach_validation(self):
        base=json.loads(Path('config/session.example.json').read_text())
        base['sources'][1]['approach']='North'
        with self.assertRaises(ValueError): validate_session(base)
    def test_command_conflict_rejected(self):
        self.assertEqual(encode_signals({'North':'green','East':'red','South':'red','West':'red'}),'GRRR')
        with self.assertRaises(ValueError): encode_signals({'North':'green','East':'green','South':'red','West':'red'})

if __name__=='__main__': unittest.main()
