import unittest
from trafficsense.core import PassageCounter

class PassageTests(unittest.TestCase):
    def test_stationary_and_crossing_deduplication(self):
        c=PassageCounter([[0,.5],[1,.5]])
        for t in range(5):c.update(1,(.2,.2),t)
        self.assertEqual(c.total,0)
        self.assertTrue(c.update(1,(.2,.7),5))
        c.update(1,(.2,.2),6);c.update(1,(.2,.7),7)
        c.update(1,(.2,.2),20);c.update(1,(.2,.7),21)
        self.assertEqual(c.total,1)
        c.update(2,(.4,.7),21);c.update(2,(.4,.2),22)
        self.assertEqual(c.total,2)
    def test_direction_segment_and_track_gap(self):
        c=PassageCounter([[.2,.5],[.8,.5]],1)
        c.update(1,(.4,.7),0);c.update(1,(.4,.2),1)
        c.update(2,(.9,.2),0);c.update(2,(.9,.7),1)
        c.update(3,(.4,.2),0);c.update(3,(.4,.7),10)
        self.assertEqual(c.total,0)
        c.update(4,(.4,.2),10);c.update(4,(.4,.7),11)
        self.assertEqual(c.total,1)

class CountingCalibrationTests(unittest.TestCase):
    def test_counting_region_persists_and_excludes_opposing_carriageway(self):
        import tempfile
        from pathlib import Path
        from trafficsense.server import TrafficApp
        from trafficsense.incidents import inside
        geometry={'region':[[.1,.1],[.6,.1],[.8,.9],[.1,.9]],'line':[[.1,.5],[.7,.5]],'direction':1}
        with tempfile.TemporaryDirectory() as tmp:
            app=TrafficApp(runtime=tmp);source=Path(tmp)/'uploads/a.mp4';source.write_bytes(b'fixture')
            (Path(tmp)/'previews/East.jpg').write_bytes(b'fixture')
            app.previews['East']={'source':str(source),'preview_id':'test','url':'/api/preview.jpg?approach=East'}
            app.dashboard.calibrate_counting('Right',geometry)
            config=TrafficApp(runtime=tmp).dashboard.configuration();s=config['sources'][0]
            self.assertTrue(config['analysis_only']);self.assertTrue(s['count_only'])
            self.assertEqual(s['stop_line'],geometry['line'])
            self.assertTrue(inside((.4,.5),s['count_region']))
            self.assertFalse(inside((.9,.5),s['count_region']))
