import tempfile
import unittest
from pathlib import Path
from trafficsense.training import inspect_dataset

class DatasetTests(unittest.TestCase):
    def fixture(self, root):
        for split in ('train', 'val', 'test'):
            (root/'images'/split).mkdir(parents=True)
            (root/'labels'/split).mkdir(parents=True)
            (root/'images'/split/'one.jpg').write_bytes(split.encode())
            (root/'labels'/split/'one.txt').write_text('0 0.5 0.5 0.5 0.2\n')

    def test_valid_and_missing_annotation(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); self.fixture(root)
            report=inspect_dataset(root,'plate')
            self.assertEqual(report['splits']['test']['class_boxes'],[1])
            (root/'labels/test/one.txt').unlink()
            with self.assertRaisesRegex(ValueError,'Missing annotation'):
                inspect_dataset(root,'plate')

    def test_leakage_and_invalid_box(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); self.fixture(root)
            (root/'images/test/one.jpg').write_bytes(b'train')
            with self.assertRaisesRegex(ValueError,'Data leakage'):
                inspect_dataset(root,'plate')
            (root/'images/test/one.jpg').write_bytes(b'test')
            for row in ['0 nan .5 .2 .2', '0 .1 .5 .8 .2', '1 .5 .5 .2 .2']:
                (root/'labels/test/one.txt').write_text(row)
                with self.assertRaisesRegex(ValueError,'Invalid YOLO box'):
                    inspect_dataset(root,'plate')
