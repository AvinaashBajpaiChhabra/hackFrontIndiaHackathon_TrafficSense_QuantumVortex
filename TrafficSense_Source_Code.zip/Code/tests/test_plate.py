import unittest
from trafficsense.vision import plate_text

class PlateTests(unittest.TestCase):
    def fragment(self,text,x,y,score=.9):
        return ([[x,y],[x+30,y],[x+30,y+10],[x,y+10]],text,score)
    def test_two_lines_and_split_fragments(self):
        result=[self.fragment('1234',40,20),self.fragment('DL',0,0),self.fragment('01',40,0),self.fragment('AB',0,20)]
        self.assertEqual(plate_text(result),('DL01AB1234',.9))
    def test_unread_and_low_confidence(self):
        self.assertEqual(plate_text([]),(None,None))
        self.assertEqual(plate_text([self.fragment('ABC123',0,0,.1)]),(None,None))
        self.assertEqual(plate_text([self.fragment('X'*20,0,0)]),(None,None))
