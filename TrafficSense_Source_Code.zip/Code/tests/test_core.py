import tempfile
import unittest
from pathlib import Path
from trafficsense.core import Controller, CrossingDetector, Timing
from trafficsense.store import Store
from trafficsense.vision import signal_at, load_config, read_signals

class ControllerTests(unittest.TestCase):
    def test_clearance_and_green_bounds(self):
        c=Controller(Timing(min_green=2,max_green=4,yellow=1,all_red=1,max_wait=10))
        c.advance(3.9,[50,50,50,50]); self.assertEqual(c.stage,'green')
        c.advance(.1,[50]*4); self.assertEqual(c.stage,'yellow')
        c.advance(1,[50]*4); self.assertEqual(c.stage,'all_red')
        self.assertEqual(set(c.snapshot()['signals'].values()),{'red'})
        c.advance(1,[50]*4); self.assertEqual(c.stage,'green'); self.assertNotEqual(c.active,0)

    def test_waiting_approaches_eventually_served(self):
        c=Controller(Timing(min_green=2,max_green=4,yellow=1,all_red=1,max_wait=8))
        seen=set()
        for _ in range(1000):
            c.advance(.1,[50,1,1,1])
            signals=c.snapshot()['signals']
            self.assertLessEqual(list(signals.values()).count('green'),1)
            if c.stage=='green': seen.add(c.active)
        self.assertEqual(seen,{0,1,2,3})

    def test_invalid_inputs(self):
        with self.assertRaises(ValueError): Timing(min_green=50,max_green=1)
        with self.assertRaises(ValueError): Controller().advance(1,[-1,0,0,0])

class CrossingTests(unittest.TestCase):
    def detector(self): return CrossingDetector([[0,.5],[1,.5]])
    def test_red_crossing_deduplicated(self):
        d=self.detector()
        self.assertFalse(d.update(1,(.5,.4),0,'red'))
        self.assertTrue(d.update(1,(.5,.6),1,'red'))
        self.assertFalse(d.update(1,(.5,.4),1.5,'red'))
        self.assertFalse(d.update(1,(.5,.6),2,'red'))
    def test_green_reverse_unknown_and_outside_not_violations(self):
        for signal in ['green','yellow','unknown']:
            d=self.detector();d.update(1,(.5,.4),0,signal)
            self.assertFalse(d.update(1,(.5,.6),1,signal))
        d=self.detector();d.update(1,(.5,.6),0,'red')
        self.assertFalse(d.update(1,(.5,.4),1,'red'))
        d=self.detector();d.update(1,(1.5,.4),0,'red')
        self.assertFalse(d.update(1,(1.5,.6),1,'red'))
    def test_expired_track_does_not_cross(self):
        d=self.detector();d.update(1,(.5,.4),0,'red')
        self.assertFalse(d.update(1,(.5,.6),10,'red'))
    def test_directed_line(self):
        d=CrossingDetector([[0,.5],[1,.5]],-1)
        d.update(1,(.5,.6),0,'red');self.assertTrue(d.update(1,(.5,.4),1,'red'))

class IntegrationTests(unittest.TestCase):
    def test_store_and_demo_isolation(self):
        with tempfile.TemporaryDirectory() as tmp:
            store=Store(Path(tmp)/'events.db')
            for source in ['demo','video']:
                store.add({'source':source,'plate':None})
            self.assertEqual(len(store.events('video')),1)
            store.clear_demo()
            self.assertEqual(len(store.events()),1)
            self.assertEqual(store.events()[0]['source'],'video')
    def test_config_and_timeline(self):
        c=load_config(Path('config/session.example.json'))
        self.assertEqual(c['sources'][0]['approach'],'North')
        timeline=read_signals('config/signals.example.csv')
        self.assertEqual(signal_at(timeline,18),'red')
        self.assertEqual(signal_at([],10),'unknown')
        self.assertEqual(signal_at(timeline,16),'yellow')

if __name__=='__main__': unittest.main()
