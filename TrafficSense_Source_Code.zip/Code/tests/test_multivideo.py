"""Controlled four-video integration; mocked detectors, real video IO and evidence storage."""
import importlib.util
import tempfile
import threading
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from trafficsense.server import TrafficApp
from trafficsense.session import validate_session

class Values:
    def __init__(self,v): self.v=v
    def cpu(self): return self
    def int(self): return self
    def tolist(self): return self.v
    def __len__(self): return len(self.v)

def result(rows,ids=True):
    return SimpleNamespace(boxes=SimpleNamespace(xyxy=Values([r[0] for r in rows]),cls=Values([r[1] for r in rows]),
        conf=Values([.95]*len(rows)),id=Values([r[2] for r in rows]) if ids else None))

class FakeModel:
    trackers=[]
    def __init__(self,path):
        self.helmet='helmet' in str(path);self.frame=0
        self.names={0:'bare human head',1:'motorcycle helmet'} if self.helmet else {0:'person',2:'car',3:'motorcycle'}
        if not self.helmet: self.trackers.append(self)
    def track(self,frame,**kwargs):
        camera=round(float(frame[10,100,0])/60);i=self.frame;self.frame+=1
        if camera==0:
            bottom=min(330,130+20*i);rows=[([150,bottom-80,350,bottom],2,1)]
        elif camera in (1,2): rows=[([200,200,400,350],3,13),([240,50,350,280],0,12)]
        else: rows=[([200,200,400,350],3,13)]
        return [result(rows)]
    def predict(self,frame,**kwargs):
        camera=round(float(frame[10,100,0])/60)
        rows=[([260,60,300,100],0,0)]
        if camera==2: rows.append(([260,60,300,100],1,0))
        return [result(rows,False)]

@unittest.skipUnless(importlib.util.find_spec('cv2') and importlib.util.find_spec('ultralytics'),'Optional vision packages unavailable')
class FourVideoTests(unittest.TestCase):
    def test_isolated_trackers_typed_events_evidence_and_uncertain_exclusion(self):
        import cv2
        import numpy as np
        from trafficsense.multivideo import run_session
        FakeModel.trackers=[]
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);sources=[]
            for i,name in enumerate(('North','East','South','West')):
                path=root/(name+'.mp4');writer=cv2.VideoWriter(str(path),cv2.VideoWriter_fourcc(*'mp4v'),5,(640,400))
                self.assertTrue(writer.isOpened())
                frame=np.zeros((400,640,3),dtype=np.uint8);frame[:,:,0]=i*60;frame[0:60,0:60]=(0,0,255)
                for _ in range(30): writer.write(frame)
                writer.release()
                sources.append({'approach':name,'source':str(path),'roi':[0,0,1,.6] if i==0 else [0,0,1,1],
                    'stop_line':[[0,.5],[1,.5]] if i==0 else [[0,.99],[1,.99]],'direction':1,
                    'signal_roi':[0,0,.08,.12],'crosswalk':[[.1,.75],[.9,.75],[.9,.9],[.1,.9]] if i==0 else None})
            cfg=validate_session({'sources':sources,'junction':'Controlled fixture junction','ocr':False,'emergency_model':None,
                'helmet_model':'helmet-world.pt','analysis_fps':5})
            app=TrafficApp(runtime=root/'runtime');app.mode='video';app.running=True;app.session_id='controlled-test';app.pipeline_state='loading';app.config=cfg
            with patch('ultralytics.YOLO',FakeModel): run_session(app,cfg,threading.Event())
            self.assertIsNone(app.error,app.error)
            self.assertEqual(len(FakeModel.trackers),4)
            self.assertEqual([m.frame for m in FakeModel.trackers],[30]*4)
            events=app.store.events('video')
            self.assertEqual(sorted((e['approach'],e['violation_type']) for e in events),
                [('East','no_helmet'),('North','crossing_obstruction'),('North','red_light')])
            for event in events:
                self.assertEqual(event['place'],'Controlled fixture junction')
                self.assertIsNotNone(event['video_time']);self.assertEqual(event['review_status'],'needs_review')
                self.assertTrue((app.runtime/'evidence'/Path(event['evidence']).name).is_file())
                self.assertTrue((app.runtime/'evidence'/Path(event['vehicle_image']).name).is_file())
            self.assertFalse(app.hardware_signals())
            self.assertEqual(app.pipeline_state,'finished')
            self.assertEqual(app.event_jobs,0)

if __name__=='__main__': unittest.main()
