"""Native firmware state-machine test with Arduino I/O stubs (not a board upload)."""
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

class FirmwareTests(unittest.TestCase):
    @unittest.skipUnless(shutil.which('clang++') or shutil.which('g++'),'C++ compiler unavailable')
    def test_firmware_interlocks_and_watchdog(self):
        sketch=Path('arduino/TrafficSenseController/TrafficSenseController.ino').resolve()
        stub=r'''
#include <cstring>
#include <cstdio>
#include <cassert>
#include <string>
using byte=unsigned char;
const int HIGH=1,LOW=0,OUTPUT=1;
unsigned long clockNow=0;
int levels[14]={0};
unsigned long millis(){return clockNow;}
void pinMode(byte,int){}
void digitalWrite(byte p,int x){levels[p]=x;}
struct SerialStub {
 std::string input,output;
 void begin(int){}
 int available(){return !input.empty();}
 char read(){char c=input.front();input.erase(0,1);return c;}
 void print(const char*s){output+=s;}
 void print(char c){output+=c;}
 void print(unsigned long n){output+=std::to_string(n);}
 void println(const char*s){output+=s;output+='\n';}
} Serial;
'''
        checks=r'''
void send(const char*s){Serial.input=s;loop();}
int main(){
 setup();assert(strcmp(current,"RRRR")==0);
 send("SET 1 GRRR\n");assert(strcmp(current,"RRRR")==0);
 clockNow=2100;send("SET 2 GRRR\n");assert(strcmp(current,"GRRR")==0);
 send("SET 3 RGRR\n");assert(strcmp(current,"GRRR")==0);
 send("SET 4 GGRR\n");assert(strcmp(current,"GRRR")==0);
 clockNow=2200;send("SET 5 YRRR\n");assert(strcmp(current,"YRRR")==0);
 clockNow=3000;send("SET 6 RRRR\n");assert(strcmp(current,"YRRR")==0);
 clockNow=5200;send("SET 7 RRRR\n");assert(strcmp(current,"RRRR")==0);
 clockNow=6000;send("SET 8 RGRR\n");assert(strcmp(current,"RRRR")==0);
 clockNow=7300;send("SET 9 RGRR\n");assert(strcmp(current,"RGRR")==0);
 clockNow=10400;loop();assert(strcmp(current,"RRRR")==0);
 clockNow=12500;send("SET 10 RRGR\n");assert(strcmp(current,"RRGR")==0);
 send("STOP 11\n");assert(strcmp(current,"RRRR")==0);
 assert(levels[2]==HIGH&&levels[5]==HIGH&&levels[8]==HIGH&&levels[11]==HIGH);
 clockNow=14600;send("SET 12 GRRR\n");assert(strcmp(current,"GRRR")==0);
 clockNow=16000;send("STATUS 13\n");assert(Serial.output.find("STATE 13 GRRR")!=std::string::npos);
 assert(lastValid==14600); // Diagnostics are not a control heartbeat.
 clockNow=17700;loop();assert(strcmp(current,"RRRR")==0);
 send("SET 14 GGRR\n");assert(strcmp(current,"RRRR")==0);
 send("SET 15 GRRR extra\n");assert(strcmp(current,"RRRR")==0);
 send("SET 16 GRRRxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\n");assert(strcmp(current,"RRRR")==0);
 clockNow=19800;send("SET 17 GRRR\n");assert(strcmp(current,"GRRR")==0);
}
'''
        with tempfile.TemporaryDirectory() as tmp:
            source=Path(tmp)/'test.cpp';binary=Path(tmp)/'test'
            source.write_text(stub+'\n#include "'+str(sketch)+'"\n'+checks)
            subprocess.run([shutil.which('clang++') or shutil.which('g++'),'-std=c++11',str(source),'-o',str(binary)],check=True,capture_output=True)
            subprocess.run([str(binary)],check=True,capture_output=True)
